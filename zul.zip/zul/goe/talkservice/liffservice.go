package talkservice

import(
	"context"
	"database/sql/driver"
	"errors"
	"fmt"
	thrift "../thrift2"
)

type LiffErrorCode int64
const (
  LiffErrorCode_INVALID_REQUEST LiffErrorCode = 1
  LiffErrorCode_UNAUTHORIZED LiffErrorCode = 2
  LiffErrorCode_CONSENT_REQUIRED LiffErrorCode = 3
  LiffErrorCode_VERSION_UPDATE_REQUIRED LiffErrorCode = 4
  LiffErrorCode_SERVER_ERROR LiffErrorCode = 100
)

func (p LiffErrorCode) String() string {
  switch p {
  case LiffErrorCode_INVALID_REQUEST: return "INVALID_REQUEST"
  case LiffErrorCode_UNAUTHORIZED: return "UNAUTHORIZED"
  case LiffErrorCode_CONSENT_REQUIRED: return "CONSENT_REQUIRED"
  case LiffErrorCode_VERSION_UPDATE_REQUIRED: return "VERSION_UPDATE_REQUIRED"
  case LiffErrorCode_SERVER_ERROR: return "SERVER_ERROR"
  }
  return "<UNSET>"
}

func LiffErrorCodeFromString(s string) (LiffErrorCode, error) {
  switch s {
  case "INVALID_REQUEST": return LiffErrorCode_INVALID_REQUEST, nil 
  case "UNAUTHORIZED": return LiffErrorCode_UNAUTHORIZED, nil 
  case "CONSENT_REQUIRED": return LiffErrorCode_CONSENT_REQUIRED, nil 
  case "VERSION_UPDATE_REQUIRED": return LiffErrorCode_VERSION_UPDATE_REQUIRED, nil 
  case "SERVER_ERROR": return LiffErrorCode_SERVER_ERROR, nil 
  }
  return LiffErrorCode(0), fmt.Errorf("not a valid LiffErrorCode string")
}


func LiffErrorCodePtr(v LiffErrorCode) *LiffErrorCode { return &v }

func (p LiffErrorCode) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *LiffErrorCode) UnmarshalText(text []byte) error {
q, err := LiffErrorCodeFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *LiffErrorCode) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = LiffErrorCode(v)
return nil
}

func (p * LiffErrorCode) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}
type LiffViewFeatures int64
const (
  LiffViewFeatures_ADVERTISING_ID LiffViewFeatures = 2
  LiffViewFeatures_BLUETOOTH_LE LiffViewFeatures = 3
  LiffViewFeatures_GEOLOCATION LiffViewFeatures = 1
)

func (p LiffViewFeatures) String() string {
  switch p {
  case LiffViewFeatures_ADVERTISING_ID: return "ADVERTISING_ID"
  case LiffViewFeatures_BLUETOOTH_LE: return "BLUETOOTH_LE"
  case LiffViewFeatures_GEOLOCATION: return "GEOLOCATION"
  }
  return "<UNSET>"
}

func LiffViewFeaturesFromString(s string) (LiffViewFeatures, error) {
  switch s {
  case "ADVERTISING_ID": return LiffViewFeatures_ADVERTISING_ID, nil 
  case "BLUETOOTH_LE": return LiffViewFeatures_BLUETOOTH_LE, nil 
  case "GEOLOCATION": return LiffViewFeatures_GEOLOCATION, nil 
  }
  return LiffViewFeatures(0), fmt.Errorf("not a valid LiffViewFeatures string")
}


func LiffViewFeaturesPtr(v LiffViewFeatures) *LiffViewFeatures { return &v }

func (p LiffViewFeatures) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *LiffViewFeatures) UnmarshalText(text []byte) error {
q, err := LiffViewFeaturesFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *LiffViewFeatures) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = LiffViewFeatures(v)
return nil
}

func (p * LiffViewFeatures) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}
// Attributes:
//  - Code
//  - Message
//  - Payload
type LiffException struct {
  Code LiffErrorCode `thrift:"code,1" db:"code" json:"code"`
  Message string `thrift:"message,2" db:"message" json:"message"`
  Payload *LiffErrorPayload `thrift:"payload,3" db:"payload" json:"payload"`
}

func NewLiffException() *LiffException {
  return &LiffException{}
}


func (p *LiffException) GetCode() LiffErrorCode {
  return p.Code
}

func (p *LiffException) GetMessage() string {
  return p.Message
}
var LiffException_Payload_DEFAULT *LiffErrorPayload
func (p *LiffException) GetPayload() *LiffErrorPayload {
  if !p.IsSetPayload() {
    return LiffException_Payload_DEFAULT
  }
return p.Payload
}
func (p *LiffException) IsSetPayload() bool {
  return p.Payload != nil
}

func (p *LiffException) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffException)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  temp := LiffErrorCode(v)
  p.Code = temp
}
  return nil
}

func (p *LiffException)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Message = v
}
  return nil
}

func (p *LiffException)  ReadField3(iprot thrift.TProtocol) error {
  p.Payload = &LiffErrorPayload{}
  if err := p.Payload.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Payload), err)
  }
  return nil
}

func (p *LiffException) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffException"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffException) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("code", thrift.I32, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:code: ", p), err) }
  if err := oprot.WriteI32(int32(p.Code)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.code (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:code: ", p), err) }
  return err
}

func (p *LiffException) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("message", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:message: ", p), err) }
  if err := oprot.WriteString(string(p.Message)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.message (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:message: ", p), err) }
  return err
}

func (p *LiffException) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("payload", thrift.STRUCT, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:payload: ", p), err) }
  if err := p.Payload.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Payload), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:payload: ", p), err) }
  return err
}

func (p *LiffException) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffException(%+v)", *p)
}

func (p *LiffException) Error() string {
  return p.String()
}

// Attributes:
//  - AccessToken
type RevokeTokenRequest struct {
  AccessToken string `thrift:"accessToken,1" db:"accessToken" json:"accessToken"`
}

func NewRevokeTokenRequest() *RevokeTokenRequest {
  return &RevokeTokenRequest{}
}


func (p *RevokeTokenRequest) GetAccessToken() string {
  return p.AccessToken
}
func (p *RevokeTokenRequest) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *RevokeTokenRequest)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.AccessToken = v
}
  return nil
}

func (p *RevokeTokenRequest) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("RevokeTokenRequest"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *RevokeTokenRequest) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("accessToken", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:accessToken: ", p), err) }
  if err := oprot.WriteString(string(p.AccessToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.accessToken (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:accessToken: ", p), err) }
  return err
}

func (p *RevokeTokenRequest) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("RevokeTokenRequest(%+v)", *p)
}

// Attributes:
//  - ChatMid
type LiffChatContext struct {
  ChatMid string `thrift:"chatMid,1" db:"chatMid" json:"chatMid"`
}

func NewLiffChatContext() *LiffChatContext {
  return &LiffChatContext{}
}


func (p *LiffChatContext) GetChatMid() string {
  return p.ChatMid
}
func (p *LiffChatContext) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffChatContext)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChatMid = v
}
  return nil
}

func (p *LiffChatContext) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffChatContext"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffChatContext) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("chatMid", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:chatMid: ", p), err) }
  if err := oprot.WriteString(string(p.ChatMid)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.chatMid (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:chatMid: ", p), err) }
  return err
}

func (p *LiffChatContext) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffChatContext(%+v)", *p)
}

// Attributes:
//  - None
//  - Chat
//  - SquareChat
type LiffContext struct {
  None *LiffNoneContext `thrift:"none,1" db:"none" json:"none"`
  Chat *LiffChatContext `thrift:"chat,2" db:"chat" json:"chat"`
  SquareChat *LiffSquareChatContext `thrift:"squareChat,3" db:"squareChat" json:"squareChat"`
}

func NewLiffContext() *LiffContext {
  return &LiffContext{}
}

var LiffContext_None_DEFAULT *LiffNoneContext
func (p *LiffContext) GetNone() *LiffNoneContext {
  if !p.IsSetNone() {
    return LiffContext_None_DEFAULT
  }
return p.None
}
var LiffContext_Chat_DEFAULT *LiffChatContext
func (p *LiffContext) GetChat() *LiffChatContext {
  if !p.IsSetChat() {
    return LiffContext_Chat_DEFAULT
  }
return p.Chat
}
var LiffContext_SquareChat_DEFAULT *LiffSquareChatContext
func (p *LiffContext) GetSquareChat() *LiffSquareChatContext {
  if !p.IsSetSquareChat() {
    return LiffContext_SquareChat_DEFAULT
  }
return p.SquareChat
}
func (p *LiffContext) IsSetNone() bool {
  return p.None != nil
}

func (p *LiffContext) IsSetChat() bool {
  return p.Chat != nil
}

func (p *LiffContext) IsSetSquareChat() bool {
  return p.SquareChat != nil
}

func (p *LiffContext) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffContext)  ReadField1(iprot thrift.TProtocol) error {
  p.None = &LiffNoneContext{}
  if err := p.None.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.None), err)
  }
  return nil
}

func (p *LiffContext)  ReadField2(iprot thrift.TProtocol) error {
  p.Chat = &LiffChatContext{}
  if err := p.Chat.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Chat), err)
  }
  return nil
}

func (p *LiffContext)  ReadField3(iprot thrift.TProtocol) error {
  p.SquareChat = &LiffSquareChatContext{}
  if err := p.SquareChat.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.SquareChat), err)
  }
  return nil
}

func (p *LiffContext) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffContext"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if p.None != nil{
      if err := p.writeField1(oprot); err != nil { return err }
    }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffContext) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("none", thrift.STRUCT, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:none: ", p), err) }
  if err := p.None.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.None), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:none: ", p), err) }
  return err
}

func (p *LiffContext) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("chat", thrift.STRUCT, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:chat: ", p), err) }
  if err := p.Chat.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Chat), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:chat: ", p), err) }
  return err
}

func (p *LiffContext) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("squareChat", thrift.STRUCT, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:squareChat: ", p), err) }
  if err := p.SquareChat.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.SquareChat), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:squareChat: ", p), err) }
  return err
}

func (p *LiffContext) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffContext(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - ConsentUrl
type LiffErrorConsentRequired struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  ConsentUrl string `thrift:"consentUrl,2" db:"consentUrl" json:"consentUrl"`
}

func NewLiffErrorConsentRequired() *LiffErrorConsentRequired {
  return &LiffErrorConsentRequired{}
}


func (p *LiffErrorConsentRequired) GetChannelId() string {
  return p.ChannelId
}

func (p *LiffErrorConsentRequired) GetConsentUrl() string {
  return p.ConsentUrl
}
func (p *LiffErrorConsentRequired) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffErrorConsentRequired)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *LiffErrorConsentRequired)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ConsentUrl = v
}
  return nil
}

func (p *LiffErrorConsentRequired) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffErrorConsentRequired"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffErrorConsentRequired) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *LiffErrorConsentRequired) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("consentUrl", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:consentUrl: ", p), err) }
  if err := oprot.WriteString(string(p.ConsentUrl)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.consentUrl (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:consentUrl: ", p), err) }
  return err
}

func (p *LiffErrorConsentRequired) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffErrorConsentRequired(%+v)", *p)
}

// Attributes:
//  - ConsentRequired
type LiffErrorPayload struct {
  // unused fields # 1 to 2
  ConsentRequired *LiffErrorConsentRequired `thrift:"consentRequired,3" db:"consentRequired" json:"consentRequired"`
}

func NewLiffErrorPayload() *LiffErrorPayload {
  return &LiffErrorPayload{}
}

var LiffErrorPayload_ConsentRequired_DEFAULT *LiffErrorConsentRequired
func (p *LiffErrorPayload) GetConsentRequired() *LiffErrorConsentRequired {
  if !p.IsSetConsentRequired() {
    return LiffErrorPayload_ConsentRequired_DEFAULT
  }
return p.ConsentRequired
}
func (p *LiffErrorPayload) IsSetConsentRequired() bool {
  return p.ConsentRequired != nil
}

func (p *LiffErrorPayload) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 3:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffErrorPayload)  ReadField3(iprot thrift.TProtocol) error {
  p.ConsentRequired = &LiffErrorConsentRequired{}
  if err := p.ConsentRequired.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.ConsentRequired), err)
  }
  return nil
}

func (p *LiffErrorPayload) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffErrorPayload"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffErrorPayload) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("consentRequired", thrift.STRUCT, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:consentRequired: ", p), err) }
  if err := p.ConsentRequired.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.ConsentRequired), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:consentRequired: ", p), err) }
  return err
}

func (p *LiffErrorPayload) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffErrorPayload(%+v)", *p)
}

type LiffNoneContext struct {
}

func NewLiffNoneContext() *LiffNoneContext {
  return &LiffNoneContext{}
}

func (p *LiffNoneContext) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    if err := iprot.Skip(fieldTypeId); err != nil {
      return err
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffNoneContext) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffNoneContext"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffNoneContext) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffNoneContext(%+v)", *p)
}

// Attributes:
//  - SquareChatMid
type LiffSquareChatContext struct {
  SquareChatMid string `thrift:"squareChatMid,1" db:"squareChatMid" json:"squareChatMid"`
}

func NewLiffSquareChatContext() *LiffSquareChatContext {
  return &LiffSquareChatContext{}
}


func (p *LiffSquareChatContext) GetSquareChatMid() string {
  return p.SquareChatMid
}
func (p *LiffSquareChatContext) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffSquareChatContext)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.SquareChatMid = v
}
  return nil
}

func (p *LiffSquareChatContext) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffSquareChatContext"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffSquareChatContext) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("squareChatMid", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:squareChatMid: ", p), err) }
  if err := oprot.WriteString(string(p.SquareChatMid)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.squareChatMid (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:squareChatMid: ", p), err) }
  return err
}

func (p *LiffSquareChatContext) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffSquareChatContext(%+v)", *p)
}

// Attributes:
//  - Type
//  - URL
//  - TrustedDomain
//  - TitleIconUrl
//  - TitleTextColor
//  - TitleSubtextColor
//  - TitleButtonColor
//  - TitleBackgroundColor
//  - ProgressBarColor
//  - ProgressBackgroundColor
type LiffView struct {
  Type string `thrift:"type,1" db:"type" json:"type"`
  URL string `thrift:"url,2" db:"url" json:"url"`
  // unused field # 3
  TitleTextColor int32 `thrift:"titleTextColor,4" db:"titleTextColor" json:"titleTextColor"`
  TitleBackgroundColor int32 `thrift:"titleBackgroundColor,5" db:"titleBackgroundColor" json:"titleBackgroundColor"`
  TitleIconUrl string `thrift:"titleIconUrl,6" db:"titleIconUrl" json:"titleIconUrl"`
  TitleSubtextColor int32 `thrift:"titleSubtextColor,7" db:"titleSubtextColor" json:"titleSubtextColor"`
  TitleButtonColor int32 `thrift:"titleButtonColor,8" db:"titleButtonColor" json:"titleButtonColor"`
  ProgressBarColor int32 `thrift:"progressBarColor,9" db:"progressBarColor" json:"progressBarColor"`
  ProgressBackgroundColor int32 `thrift:"progressBackgroundColor,10" db:"progressBackgroundColor" json:"progressBackgroundColor"`
  TrustedDomain bool `thrift:"trustedDomain,11" db:"trustedDomain" json:"trustedDomain"`
}

func NewLiffView() *LiffView {
  return &LiffView{}
}


func (p *LiffView) GetType() string {
  return p.Type
}

func (p *LiffView) GetURL() string {
  return p.URL
}

func (p *LiffView) GetTrustedDomain() bool {
  return p.TrustedDomain
}

func (p *LiffView) GetTitleIconUrl() string {
  return p.TitleIconUrl
}

func (p *LiffView) GetTitleTextColor() int32 {
  return p.TitleTextColor
}

func (p *LiffView) GetTitleSubtextColor() int32 {
  return p.TitleSubtextColor
}

func (p *LiffView) GetTitleButtonColor() int32 {
  return p.TitleButtonColor
}

func (p *LiffView) GetTitleBackgroundColor() int32 {
  return p.TitleBackgroundColor
}

func (p *LiffView) GetProgressBarColor() int32 {
  return p.ProgressBarColor
}

func (p *LiffView) GetProgressBackgroundColor() int32 {
  return p.ProgressBackgroundColor
}
func (p *LiffView) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 11:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField11(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 6:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField6(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 7:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField7(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 8:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField8(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 5:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField5(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 9:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField9(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 10:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField10(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffView)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.Type = v
}
  return nil
}

func (p *LiffView)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.URL = v
}
  return nil
}

func (p *LiffView)  ReadField11(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 11: ", err)
} else {
  p.TrustedDomain = v
}
  return nil
}

func (p *LiffView)  ReadField6(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 6: ", err)
} else {
  p.TitleIconUrl = v
}
  return nil
}

func (p *LiffView)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.TitleTextColor = v
}
  return nil
}

func (p *LiffView)  ReadField7(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 7: ", err)
} else {
  p.TitleSubtextColor = v
}
  return nil
}

func (p *LiffView)  ReadField8(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 8: ", err)
} else {
  p.TitleButtonColor = v
}
  return nil
}

func (p *LiffView)  ReadField5(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 5: ", err)
} else {
  p.TitleBackgroundColor = v
}
  return nil
}

func (p *LiffView)  ReadField9(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 9: ", err)
} else {
  p.ProgressBarColor = v
}
  return nil
}

func (p *LiffView)  ReadField10(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 10: ", err)
} else {
  p.ProgressBackgroundColor = v
}
  return nil
}

func (p *LiffView) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffView"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
    if err := p.writeField5(oprot); err != nil { return err }
    if err := p.writeField6(oprot); err != nil { return err }
    if err := p.writeField7(oprot); err != nil { return err }
    if err := p.writeField8(oprot); err != nil { return err }
    if err := p.writeField9(oprot); err != nil { return err }
    if err := p.writeField10(oprot); err != nil { return err }
    if err := p.writeField11(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffView) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("type", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:type: ", p), err) }
  if err := oprot.WriteString(string(p.Type)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.type (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:type: ", p), err) }
  return err
}

func (p *LiffView) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("url", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:url: ", p), err) }
  if err := oprot.WriteString(string(p.URL)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.url (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:url: ", p), err) }
  return err
}

func (p *LiffView) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("titleTextColor", thrift.I32, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:titleTextColor: ", p), err) }
  if err := oprot.WriteI32(int32(p.TitleTextColor)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.titleTextColor (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:titleTextColor: ", p), err) }
  return err
}

func (p *LiffView) writeField5(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("titleBackgroundColor", thrift.I32, 5); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 5:titleBackgroundColor: ", p), err) }
  if err := oprot.WriteI32(int32(p.TitleBackgroundColor)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.titleBackgroundColor (5) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 5:titleBackgroundColor: ", p), err) }
  return err
}

func (p *LiffView) writeField6(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("titleIconUrl", thrift.STRING, 6); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 6:titleIconUrl: ", p), err) }
  if err := oprot.WriteString(string(p.TitleIconUrl)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.titleIconUrl (6) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 6:titleIconUrl: ", p), err) }
  return err
}

func (p *LiffView) writeField7(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("titleSubtextColor", thrift.I32, 7); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 7:titleSubtextColor: ", p), err) }
  if err := oprot.WriteI32(int32(p.TitleSubtextColor)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.titleSubtextColor (7) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 7:titleSubtextColor: ", p), err) }
  return err
}

func (p *LiffView) writeField8(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("titleButtonColor", thrift.I32, 8); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 8:titleButtonColor: ", p), err) }
  if err := oprot.WriteI32(int32(p.TitleButtonColor)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.titleButtonColor (8) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 8:titleButtonColor: ", p), err) }
  return err
}

func (p *LiffView) writeField9(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("progressBarColor", thrift.I32, 9); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 9:progressBarColor: ", p), err) }
  if err := oprot.WriteI32(int32(p.ProgressBarColor)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.progressBarColor (9) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 9:progressBarColor: ", p), err) }
  return err
}

func (p *LiffView) writeField10(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("progressBackgroundColor", thrift.I32, 10); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 10:progressBackgroundColor: ", p), err) }
  if err := oprot.WriteI32(int32(p.ProgressBackgroundColor)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.progressBackgroundColor (10) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 10:progressBackgroundColor: ", p), err) }
  return err
}

func (p *LiffView) writeField11(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("trustedDomain", thrift.BOOL, 11); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 11:trustedDomain: ", p), err) }
  if err := oprot.WriteBool(bool(p.TrustedDomain)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.trustedDomain (11) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 11:trustedDomain: ", p), err) }
  return err
}

func (p *LiffView) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffView(%+v)", *p)
}

// Attributes:
//  - LiffId
//  - Context
type LiffViewRequest struct {
  LiffId string `thrift:"liffId,1" db:"liffId" json:"liffId"`
  Context *LiffContext `thrift:"context,2" db:"context" json:"context"`
}

func NewLiffViewRequest() *LiffViewRequest {
  return &LiffViewRequest{}
}


func (p *LiffViewRequest) GetLiffId() string {
  return p.LiffId
}
var LiffViewRequest_Context_DEFAULT *LiffContext
func (p *LiffViewRequest) GetContext() *LiffContext {
  if !p.IsSetContext() {
    return LiffViewRequest_Context_DEFAULT
  }
return p.Context
}
func (p *LiffViewRequest) IsSetContext() bool {
  return p.Context != nil
}

func (p *LiffViewRequest) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffViewRequest)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.LiffId = v
}
  return nil
}

func (p *LiffViewRequest)  ReadField2(iprot thrift.TProtocol) error {
  p.Context = &LiffContext{}
  if err := p.Context.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Context), err)
  }
  return nil
}

func (p *LiffViewRequest) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffViewRequest"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffViewRequest) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("liffId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:liffId: ", p), err) }
  if err := oprot.WriteString(string(p.LiffId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.liffId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:liffId: ", p), err) }
  return err
}

func (p *LiffViewRequest) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("context", thrift.STRUCT, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:context: ", p), err) }
  if err := p.Context.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Context), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:context: ", p), err) }
  return err
}

func (p *LiffViewRequest) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffViewRequest(%+v)", *p)
}

// Attributes:
//  - View
//  - ContextToken
//  - AccessToken
//  - FeatureToken
//  - Features
//  - ChannelId
type LiffViewResponse struct {
  View *LiffView `thrift:"view,1" db:"view" json:"view"`
  ContextToken string `thrift:"contextToken,2" db:"contextToken" json:"contextToken"`
  AccessToken string `thrift:"accessToken,3" db:"accessToken" json:"accessToken"`
  FeatureToken string `thrift:"featureToken,4" db:"featureToken" json:"featureToken"`
  Features []LiffViewFeatures `thrift:"features,5" db:"features" json:"features"`
  ChannelId string `thrift:"channelId,6" db:"channelId" json:"channelId"`
  IdToken string `thrift:"idToken,7" db:"idToken" json:"idToken"`
  Scopes []string `thrift:"scopes,8" db:"scopes" json:"scopes"`
}

func NewLiffViewResponse() *LiffViewResponse {
  return &LiffViewResponse{}
}

var LiffViewResponse_View_DEFAULT *LiffView
func (p *LiffViewResponse) GetView() *LiffView {
  if !p.IsSetView() {
    return LiffViewResponse_View_DEFAULT
  }
return p.View
}

func (p *LiffViewResponse) GetContextToken() string {
  return p.ContextToken
}

func (p *LiffViewResponse) GetAccessToken() string {
  return p.AccessToken
}

func (p *LiffViewResponse) GetFeatureToken() string {
  return p.FeatureToken
}

func (p *LiffViewResponse) GetFeatures() []LiffViewFeatures {
  return p.Features
}

func (p *LiffViewResponse) GetChannelId() string {
  return p.ChannelId
}
func (p *LiffViewResponse) IsSetView() bool {
  return p.View != nil
}

func (p *LiffViewResponse) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 5:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField5(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 6:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField6(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 7:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField7(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 8:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField8(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffViewResponse)  ReadField1(iprot thrift.TProtocol) error {
  p.View = &LiffView{}
  if err := p.View.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.View), err)
  }
  return nil
}

func (p *LiffViewResponse)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ContextToken = v
}
  return nil
}

func (p *LiffViewResponse)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.AccessToken = v
}
  return nil
}

func (p *LiffViewResponse)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.FeatureToken = v
}
  return nil
}

func (p *LiffViewResponse)  ReadField5(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]LiffViewFeatures, 0, size)
  p.Features =  tSlice
  for i := 0; i < size; i ++ {
var _elem0 LiffViewFeatures
    if v, err := iprot.ReadI32(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    temp := LiffViewFeatures(v)
    _elem0 = temp
}
    p.Features = append(p.Features, _elem0)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *LiffViewResponse)  ReadField6(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 6: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *LiffViewResponse)  ReadField7(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 7: ", err)
} else {
  p.IdToken = v
}
  return nil
}

func (p *LiffViewResponse)  ReadField8(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  slice := make([]string, 0, size)
  p.Scopes = slice
  
  tSlice := make([]LiffViewFeatures, 0, size)
  p.Features =  tSlice
  for i := 0; i < size; i ++ {
    if v, err := iprot.ReadString(); err != nil {
      return thrift.PrependError("error reading field 6: ", err)
    } else {
      p.Scopes = append(p.Scopes, v)
    }
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *LiffViewResponse) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("LiffViewResponse"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
    if err := p.writeField5(oprot); err != nil { return err }
    if err := p.writeField6(oprot); err != nil { return err }
    if err := p.writeField7(oprot); err != nil { return err }
    if err := p.writeField8(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffViewResponse) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("view", thrift.STRUCT, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:view: ", p), err) }
  if err := p.View.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.View), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:view: ", p), err) }
  return err
}

func (p *LiffViewResponse) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("contextToken", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:contextToken: ", p), err) }
  if err := oprot.WriteString(string(p.ContextToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.contextToken (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:contextToken: ", p), err) }
  return err
}

func (p *LiffViewResponse) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("accessToken", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:accessToken: ", p), err) }
  if err := oprot.WriteString(string(p.AccessToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.accessToken (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:accessToken: ", p), err) }
  return err
}

func (p *LiffViewResponse) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("featureToken", thrift.STRING, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:featureToken: ", p), err) }
  if err := oprot.WriteString(string(p.FeatureToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.featureToken (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:featureToken: ", p), err) }
  return err
}

func (p *LiffViewResponse) writeField5(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("features", thrift.LIST, 5); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 5:features: ", p), err) }
  if err := oprot.WriteListBegin(thrift.I32, len(p.Features)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.Features {
    if err := oprot.WriteI32(int32(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 5:features: ", p), err) }
  return err
}

func (p *LiffViewResponse) writeField6(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 6); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 6:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (6) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 6:channelId: ", p), err) }
  return err
}

func (p *LiffViewResponse) writeField7(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("idToken", thrift.STRING, 6); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 7:idToken: ", p), err) }
  if err := oprot.WriteString(string(p.IdToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.idToken (7) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 7:idToken: ", p), err) }
  return err
}

func (p *LiffViewResponse) writeField8(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("scopes", thrift.LIST, 8); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 8:scopes: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRING, len(p.Scopes)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.Scopes {
    if err := oprot.WriteString(string(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 8:scopes: ", p), err) }
  return err
}

func (p *LiffViewResponse) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffViewResponse(%+v)", *p)
}

type LiffService interface {
  // Parameters:
  //  - Request
  IssueLiffView(ctx context.Context, request *LiffViewRequest) (r *LiffViewResponse, err error)
  // Parameters:
  //  - Request
  RevokeToken(ctx context.Context, request *RevokeTokenRequest) (err error)
}

type LiffServiceClient struct {
  c thrift.TClient
}

// Deprecated: Use NewLiffService instead
func NewLiffServiceClientFactory(t thrift.TTransport, f thrift.TProtocolFactory) *LiffServiceClient {
  return &LiffServiceClient{
    c: thrift.NewTStandardClient(f.GetProtocol(t), f.GetProtocol(t)),
  }
}

// Deprecated: Use NewLiffService instead
func NewLiffServiceClientProtocol(t thrift.TTransport, iprot thrift.TProtocol, oprot thrift.TProtocol) *LiffServiceClient {
  return &LiffServiceClient{
    c: thrift.NewTStandardClient(iprot, oprot),
  }
}

func NewLiffServiceClient(c thrift.TClient) *LiffServiceClient {
  return &LiffServiceClient{
    c: c,
  }
}

// Parameters:
//  - Request
func (p *LiffServiceClient) IssueLiffView(ctx context.Context, request *LiffViewRequest) (r *LiffViewResponse, err error) {
  var _args1 LiffServiceIssueLiffViewArgs
  _args1.Request = request
  var _result2 LiffServiceIssueLiffViewResult
  if err = p.c.Call(ctx, "issueLiffView", &_args1, &_result2); err != nil {
    return
  }
  switch {
  case _result2.E!= nil:
    return r, _result2.E
  }

  return _result2.GetSuccess(), nil
}

// Parameters:
//  - Request
func (p *LiffServiceClient) RevokeToken(ctx context.Context, request *RevokeTokenRequest) (err error) {
  var _args3 LiffServiceRevokeTokenArgs
  _args3.Request = request
  var _result4 LiffServiceRevokeTokenResult
  if err = p.c.Call(ctx, "revokeToken", &_args3, &_result4); err != nil {
    return
  }
  switch {
  case _result4.E!= nil:
    return _result4.E
  }

  return nil
}

type LiffServiceProcessor struct {
  processorMap map[string]thrift.TProcessorFunction
  handler LiffService
}

func (p *LiffServiceProcessor) AddToProcessorMap(key string, processor thrift.TProcessorFunction) {
  p.processorMap[key] = processor
}

func (p *LiffServiceProcessor) GetProcessorFunction(key string) (processor thrift.TProcessorFunction, ok bool) {
  processor, ok = p.processorMap[key]
  return processor, ok
}

func (p *LiffServiceProcessor) ProcessorMap() map[string]thrift.TProcessorFunction {
  return p.processorMap
}

func NewLiffServiceProcessor(handler LiffService) *LiffServiceProcessor {

  self5 := &LiffServiceProcessor{handler:handler, processorMap:make(map[string]thrift.TProcessorFunction)}
  self5.processorMap["issueLiffView"] = &liffServiceProcessorIssueLiffView{handler:handler}
  self5.processorMap["revokeToken"] = &liffServiceProcessorRevokeToken{handler:handler}
return self5
}

func (p *LiffServiceProcessor) Process(ctx context.Context, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  name, _, seqId, err := iprot.ReadMessageBegin()
  if err != nil { return false, err }
  if processor, ok := p.GetProcessorFunction(name); ok {
    return processor.Process(ctx, seqId, iprot, oprot)
  }
  iprot.Skip(thrift.STRUCT)
  iprot.ReadMessageEnd()
  x6 := thrift.NewTApplicationException(thrift.UNKNOWN_METHOD, "Unknown function " + name)
  oprot.WriteMessageBegin(name, thrift.EXCEPTION, seqId)
  x6.Write(oprot)
  oprot.WriteMessageEnd()
  oprot.Flush(ctx)
  return false, x6

}

type liffServiceProcessorIssueLiffView struct {
  handler LiffService
}

func (p *liffServiceProcessorIssueLiffView) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := LiffServiceIssueLiffViewArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("issueLiffView", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := LiffServiceIssueLiffViewResult{}
var retval *LiffViewResponse
  var err2 error
  if retval, err2 = p.handler.IssueLiffView(ctx, args.Request); err2 != nil {
  switch v := err2.(type) {
    case *LiffException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing issueLiffView: " + err2.Error())
    oprot.WriteMessageBegin("issueLiffView", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("issueLiffView", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type liffServiceProcessorRevokeToken struct {
  handler LiffService
}

func (p *liffServiceProcessorRevokeToken) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := LiffServiceRevokeTokenArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("revokeToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := LiffServiceRevokeTokenResult{}
  var err2 error
  if err2 = p.handler.RevokeToken(ctx, args.Request); err2 != nil {
  switch v := err2.(type) {
    case *LiffException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing revokeToken: " + err2.Error())
    oprot.WriteMessageBegin("revokeToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  }
  if err2 = oprot.WriteMessageBegin("revokeToken", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}


// HELPER FUNCTIONS AND STRUCTURES

// Attributes:
//  - Request
type LiffServiceIssueLiffViewArgs struct {
  Request *LiffViewRequest `thrift:"request,1" db:"request" json:"request"`
}

func NewLiffServiceIssueLiffViewArgs() *LiffServiceIssueLiffViewArgs {
  return &LiffServiceIssueLiffViewArgs{}
}

var LiffServiceIssueLiffViewArgs_Request_DEFAULT *LiffViewRequest
func (p *LiffServiceIssueLiffViewArgs) GetRequest() *LiffViewRequest {
  if !p.IsSetRequest() {
    return LiffServiceIssueLiffViewArgs_Request_DEFAULT
  }
return p.Request
}
func (p *LiffServiceIssueLiffViewArgs) IsSetRequest() bool {
  return p.Request != nil
}

func (p *LiffServiceIssueLiffViewArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffServiceIssueLiffViewArgs)  ReadField1(iprot thrift.TProtocol) error {
  p.Request = &LiffViewRequest{}
  if err := p.Request.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Request), err)
  }
  return nil
}

func (p *LiffServiceIssueLiffViewArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueLiffView_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffServiceIssueLiffViewArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("request", thrift.STRUCT, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:request: ", p), err) }
  if err := p.Request.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Request), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:request: ", p), err) }
  return err
}

func (p *LiffServiceIssueLiffViewArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffServiceIssueLiffViewArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type LiffServiceIssueLiffViewResult struct {
  Success *LiffViewResponse `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *LiffException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewLiffServiceIssueLiffViewResult() *LiffServiceIssueLiffViewResult {
  return &LiffServiceIssueLiffViewResult{}
}

var LiffServiceIssueLiffViewResult_Success_DEFAULT *LiffViewResponse
func (p *LiffServiceIssueLiffViewResult) GetSuccess() *LiffViewResponse {
  if !p.IsSetSuccess() {
    return LiffServiceIssueLiffViewResult_Success_DEFAULT
  }
return p.Success
}
var LiffServiceIssueLiffViewResult_E_DEFAULT *LiffException
func (p *LiffServiceIssueLiffViewResult) GetE() *LiffException {
  if !p.IsSetE() {
    return LiffServiceIssueLiffViewResult_E_DEFAULT
  }
return p.E
}
func (p *LiffServiceIssueLiffViewResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *LiffServiceIssueLiffViewResult) IsSetE() bool {
  return p.E != nil
}

func (p *LiffServiceIssueLiffViewResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffServiceIssueLiffViewResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &LiffViewResponse{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *LiffServiceIssueLiffViewResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &LiffException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *LiffServiceIssueLiffViewResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueLiffView_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffServiceIssueLiffViewResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *LiffServiceIssueLiffViewResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *LiffServiceIssueLiffViewResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffServiceIssueLiffViewResult(%+v)", *p)
}

// Attributes:
//  - Request
type LiffServiceRevokeTokenArgs struct {
  Request *RevokeTokenRequest `thrift:"request,1" db:"request" json:"request"`
}

func NewLiffServiceRevokeTokenArgs() *LiffServiceRevokeTokenArgs {
  return &LiffServiceRevokeTokenArgs{}
}

var LiffServiceRevokeTokenArgs_Request_DEFAULT *RevokeTokenRequest
func (p *LiffServiceRevokeTokenArgs) GetRequest() *RevokeTokenRequest {
  if !p.IsSetRequest() {
    return LiffServiceRevokeTokenArgs_Request_DEFAULT
  }
return p.Request
}
func (p *LiffServiceRevokeTokenArgs) IsSetRequest() bool {
  return p.Request != nil
}

func (p *LiffServiceRevokeTokenArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffServiceRevokeTokenArgs)  ReadField1(iprot thrift.TProtocol) error {
  p.Request = &RevokeTokenRequest{}
  if err := p.Request.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Request), err)
  }
  return nil
}

func (p *LiffServiceRevokeTokenArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("revokeToken_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffServiceRevokeTokenArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("request", thrift.STRUCT, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:request: ", p), err) }
  if err := p.Request.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Request), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:request: ", p), err) }
  return err
}

func (p *LiffServiceRevokeTokenArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffServiceRevokeTokenArgs(%+v)", *p)
}

// Attributes:
//  - E
type LiffServiceRevokeTokenResult struct {
  E *LiffException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewLiffServiceRevokeTokenResult() *LiffServiceRevokeTokenResult {
  return &LiffServiceRevokeTokenResult{}
}

var LiffServiceRevokeTokenResult_E_DEFAULT *LiffException
func (p *LiffServiceRevokeTokenResult) GetE() *LiffException {
  if !p.IsSetE() {
    return LiffServiceRevokeTokenResult_E_DEFAULT
  }
return p.E
}
func (p *LiffServiceRevokeTokenResult) IsSetE() bool {
  return p.E != nil
}

func (p *LiffServiceRevokeTokenResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *LiffServiceRevokeTokenResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &LiffException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *LiffServiceRevokeTokenResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("revokeToken_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *LiffServiceRevokeTokenResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *LiffServiceRevokeTokenResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("LiffServiceRevokeTokenResult(%+v)", *p)
}