package talkservice

import(
	"context"
	"reflect"
	"database/sql/driver"
	"errors"
	"fmt"
	thrift "../thrift2"
)

type FriendChannelMatricesResponse struct {
  Expires int64 `thrift:"expires,1" db:"expires" json:"expires"`
  Matrices []*FriendChannelMatrix `thrift:"matrices,2" db:"matrices" json:"matrices"`
}

func NewFriendChannelMatricesResponse() *FriendChannelMatricesResponse {
  return &FriendChannelMatricesResponse{}
}


func (p *FriendChannelMatricesResponse) GetExpires() int64 {
  return p.Expires
}

func (p *FriendChannelMatricesResponse) GetMatrices() []*FriendChannelMatrix {
  return p.Matrices
}
func (p *FriendChannelMatricesResponse) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *FriendChannelMatricesResponse)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.Expires = v
}
  return nil
}

func (p *FriendChannelMatricesResponse)  ReadField2(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*FriendChannelMatrix, 0, size)
  p.Matrices =  tSlice
  for i := 0; i < size; i ++ {
    _elem47 := &FriendChannelMatrix{}
    if err := _elem47.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem47), err)
    }
    p.Matrices = append(p.Matrices, _elem47)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *FriendChannelMatricesResponse) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("FriendChannelMatricesResponse"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *FriendChannelMatricesResponse) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("expires", thrift.I64, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:expires: ", p), err) }
  if err := oprot.WriteI64(int64(p.Expires)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.expires (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:expires: ", p), err) }
  return err
}

func (p *FriendChannelMatricesResponse) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("matrices", thrift.LIST, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:matrices: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.Matrices)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.Matrices {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:matrices: ", p), err) }
  return err
}

func (p *FriendChannelMatricesResponse) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("FriendChannelMatricesResponse(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - RepresentMid
//  - Count
//  - Point
type FriendChannelMatrix struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  RepresentMid string `thrift:"representMid,2" db:"representMid" json:"representMid"`
  Count int32 `thrift:"count,3" db:"count" json:"count"`
  Point int32 `thrift:"point,4" db:"point" json:"point"`
}

func NewFriendChannelMatrix() *FriendChannelMatrix {
  return &FriendChannelMatrix{}
}


func (p *FriendChannelMatrix) GetChannelId() string {
  return p.ChannelId
}

func (p *FriendChannelMatrix) GetRepresentMid() string {
  return p.RepresentMid
}

func (p *FriendChannelMatrix) GetCount() int32 {
  return p.Count
}

func (p *FriendChannelMatrix) GetPoint() int32 {
  return p.Point
}
func (p *FriendChannelMatrix) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *FriendChannelMatrix)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *FriendChannelMatrix)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.RepresentMid = v
}
  return nil
}

func (p *FriendChannelMatrix)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Count = v
}
  return nil
}

func (p *FriendChannelMatrix)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.Point = v
}
  return nil
}

func (p *FriendChannelMatrix) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("FriendChannelMatrix"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *FriendChannelMatrix) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *FriendChannelMatrix) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("representMid", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:representMid: ", p), err) }
  if err := oprot.WriteString(string(p.RepresentMid)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.representMid (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:representMid: ", p), err) }
  return err
}

func (p *FriendChannelMatrix) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("count", thrift.I32, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:count: ", p), err) }
  if err := oprot.WriteI32(int32(p.Count)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.count (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:count: ", p), err) }
  return err
}

func (p *FriendChannelMatrix) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("point", thrift.I32, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:point: ", p), err) }
  if err := oprot.WriteI32(int32(p.Point)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.point (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:point: ", p), err) }
  return err
}

func (p *FriendChannelMatrix) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("FriendChannelMatrix(%+v)", *p)
}

type NotificationItemFetchMode int64
const (
  NotificationItemFetchMode_ALL NotificationItemFetchMode = 0
  NotificationItemFetchMode_APPEND NotificationItemFetchMode = 1
)

func (p NotificationItemFetchMode) String() string {
  switch p {
  case NotificationItemFetchMode_ALL: return "ALL"
  case NotificationItemFetchMode_APPEND: return "APPEND"
  }
  return "<UNSET>"
}

func NotificationItemFetchModeFromString(s string) (NotificationItemFetchMode, error) {
  switch s {
  case "ALL": return NotificationItemFetchMode_ALL, nil 
  case "APPEND": return NotificationItemFetchMode_APPEND, nil 
  }
  return NotificationItemFetchMode(0), fmt.Errorf("not a valid NotificationItemFetchMode string")
}


func NotificationItemFetchModePtr(v NotificationItemFetchMode) *NotificationItemFetchMode { return &v }

func (p NotificationItemFetchMode) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *NotificationItemFetchMode) UnmarshalText(text []byte) error {
q, err := NotificationItemFetchModeFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *NotificationItemFetchMode) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = NotificationItemFetchMode(v)
return nil
}

func (p * NotificationItemFetchMode) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}

type PaymentType int64
const (
  PaymentType_PAYMENT_APPLE PaymentType = 1
  PaymentType_PAYMENT_GOOGLE PaymentType = 2
)

func (p PaymentType) String() string {
  switch p {
  case PaymentType_PAYMENT_APPLE: return "PAYMENT_APPLE"
  case PaymentType_PAYMENT_GOOGLE: return "PAYMENT_GOOGLE"
  }
  return "<UNSET>"
}

func PaymentTypeFromString(s string) (PaymentType, error) {
  switch s {
  case "PAYMENT_APPLE": return PaymentType_PAYMENT_APPLE, nil 
  case "PAYMENT_GOOGLE": return PaymentType_PAYMENT_GOOGLE, nil 
  }
  return PaymentType(0), fmt.Errorf("not a valid PaymentType string")
}


func PaymentTypePtr(v PaymentType) *PaymentType { return &v }

func (p PaymentType) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *PaymentType) UnmarshalText(text []byte) error {
q, err := PaymentTypeFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *PaymentType) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = PaymentType(v)
return nil
}

func (p * PaymentType) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}

type CoinUseReservation struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  ShopOrderId string `thrift:"shopOrderId,2" db:"shopOrderId" json:"shopOrderId"`
  AppStoreCode PaymentType `thrift:"appStoreCode,3" db:"appStoreCode" json:"appStoreCode"`
  Items []*CoinUseReservationItem `thrift:"items,4" db:"items" json:"items"`
  Country string `thrift:"country,5" db:"country" json:"country"`
}

func NewCoinUseReservation() *CoinUseReservation {
  return &CoinUseReservation{}
}


func (p *CoinUseReservation) GetChannelId() string {
  return p.ChannelId
}

func (p *CoinUseReservation) GetShopOrderId() string {
  return p.ShopOrderId
}

func (p *CoinUseReservation) GetAppStoreCode() PaymentType {
  return p.AppStoreCode
}

func (p *CoinUseReservation) GetItems() []*CoinUseReservationItem {
  return p.Items
}

func (p *CoinUseReservation) GetCountry() string {
  return p.Country
}
func (p *CoinUseReservation) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 5:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField5(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *CoinUseReservation)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *CoinUseReservation)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ShopOrderId = v
}
  return nil
}

func (p *CoinUseReservation)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  temp := PaymentType(v)
  p.AppStoreCode = temp
}
  return nil
}

func (p *CoinUseReservation)  ReadField4(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*CoinUseReservationItem, 0, size)
  p.Items =  tSlice
  for i := 0; i < size; i ++ {
    _elem37 := &CoinUseReservationItem{}
    if err := _elem37.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem37), err)
    }
    p.Items = append(p.Items, _elem37)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *CoinUseReservation)  ReadField5(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 5: ", err)
} else {
  p.Country = v
}
  return nil
}

func (p *CoinUseReservation) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("CoinUseReservation"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
    if err := p.writeField5(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *CoinUseReservation) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *CoinUseReservation) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("shopOrderId", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:shopOrderId: ", p), err) }
  if err := oprot.WriteString(string(p.ShopOrderId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.shopOrderId (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:shopOrderId: ", p), err) }
  return err
}

func (p *CoinUseReservation) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("appStoreCode", thrift.I32, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:appStoreCode: ", p), err) }
  if err := oprot.WriteI32(int32(p.AppStoreCode)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.appStoreCode (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:appStoreCode: ", p), err) }
  return err
}

func (p *CoinUseReservation) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("items", thrift.LIST, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:items: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.Items)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.Items {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:items: ", p), err) }
  return err
}

func (p *CoinUseReservation) writeField5(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("country", thrift.STRING, 5); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 5:country: ", p), err) }
  if err := oprot.WriteString(string(p.Country)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.country (5) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 5:country: ", p), err) }
  return err
}

func (p *CoinUseReservation) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("CoinUseReservation(%+v)", *p)
}

// Attributes:
//  - ItemId
//  - ItemName
//  - Amount
type CoinUseReservationItem struct {
  ItemId string `thrift:"itemId,1" db:"itemId" json:"itemId"`
  ItemName string `thrift:"itemName,2" db:"itemName" json:"itemName"`
  Amount int32 `thrift:"amount,3" db:"amount" json:"amount"`
}

func NewCoinUseReservationItem() *CoinUseReservationItem {
  return &CoinUseReservationItem{}
}


func (p *CoinUseReservationItem) GetItemId() string {
  return p.ItemId
}

func (p *CoinUseReservationItem) GetItemName() string {
  return p.ItemName
}

func (p *CoinUseReservationItem) GetAmount() int32 {
  return p.Amount
}
func (p *CoinUseReservationItem) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *CoinUseReservationItem)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ItemId = v
}
  return nil
}

func (p *CoinUseReservationItem)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ItemName = v
}
  return nil
}

func (p *CoinUseReservationItem)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Amount = v
}
  return nil
}

func (p *CoinUseReservationItem) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("CoinUseReservationItem"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *CoinUseReservationItem) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("itemId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:itemId: ", p), err) }
  if err := oprot.WriteString(string(p.ItemId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.itemId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:itemId: ", p), err) }
  return err
}

func (p *CoinUseReservationItem) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("itemName", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:itemName: ", p), err) }
  if err := oprot.WriteString(string(p.ItemName)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.itemName (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:itemName: ", p), err) }
  return err
}

func (p *CoinUseReservationItem) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("amount", thrift.I32, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:amount: ", p), err) }
  if err := oprot.WriteI32(int32(p.Amount)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.amount (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:amount: ", p), err) }
  return err
}

func (p *CoinUseReservationItem) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("CoinUseReservationItem(%+v)", *p)
}

type NotificationFetchResult_ struct {
  FetchMode NotificationItemFetchMode `thrift:"fetchMode,1" db:"fetchMode" json:"fetchMode"`
  ItemList []*NotificationItem `thrift:"itemList,2" db:"itemList" json:"itemList"`
}

func NewNotificationFetchResult_() *NotificationFetchResult_ {
  return &NotificationFetchResult_{}
}


func (p *NotificationFetchResult_) GetFetchMode() NotificationItemFetchMode {
  return p.FetchMode
}

func (p *NotificationFetchResult_) GetItemList() []*NotificationItem {
  return p.ItemList
}
func (p *NotificationFetchResult_) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *NotificationFetchResult_)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  temp := NotificationItemFetchMode(v)
  p.FetchMode = temp
}
  return nil
}

func (p *NotificationFetchResult_)  ReadField2(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*NotificationItem, 0, size)
  p.ItemList =  tSlice
  for i := 0; i < size; i ++ {
    _elem71 := &NotificationItem{}
    if err := _elem71.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem71), err)
    }
    p.ItemList = append(p.ItemList, _elem71)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *NotificationFetchResult_) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("NotificationFetchResult"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *NotificationFetchResult_) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("fetchMode", thrift.I32, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:fetchMode: ", p), err) }
  if err := oprot.WriteI32(int32(p.FetchMode)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.fetchMode (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:fetchMode: ", p), err) }
  return err
}

func (p *NotificationFetchResult_) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("itemList", thrift.LIST, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:itemList: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ItemList)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ItemList {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:itemList: ", p), err) }
  return err
}

func (p *NotificationFetchResult_) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("NotificationFetchResult_(%+v)", *p)
}

// Attributes:
//  - ID
//  - From_
//  - To
//  - FromChannel
//  - ToChannel
//  - Revision
//  - CreatedTime
//  - Content
type NotificationItem struct {
  ID string `thrift:"id,1" db:"id" json:"id"`
  From_ string `thrift:"from_,2" db:"from_" json:"from_"`
  To string `thrift:"to,3" db:"to" json:"to"`
  FromChannel string `thrift:"fromChannel,4" db:"fromChannel" json:"fromChannel"`
  ToChannel string `thrift:"toChannel,5" db:"toChannel" json:"toChannel"`
  // unused field # 6
  Revision int64 `thrift:"revision,7" db:"revision" json:"revision"`
  CreatedTime int64 `thrift:"createdTime,8" db:"createdTime" json:"createdTime"`
  Content map[string]string `thrift:"content,9" db:"content" json:"content"`
}

func NewNotificationItem() *NotificationItem {
  return &NotificationItem{}
}


func (p *NotificationItem) GetID() string {
  return p.ID
}

func (p *NotificationItem) GetFrom_() string {
  return p.From_
}

func (p *NotificationItem) GetTo() string {
  return p.To
}

func (p *NotificationItem) GetFromChannel() string {
  return p.FromChannel
}

func (p *NotificationItem) GetToChannel() string {
  return p.ToChannel
}

func (p *NotificationItem) GetRevision() int64 {
  return p.Revision
}

func (p *NotificationItem) GetCreatedTime() int64 {
  return p.CreatedTime
}

func (p *NotificationItem) GetContent() map[string]string {
  return p.Content
}
func (p *NotificationItem) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 5:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField5(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 7:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField7(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 8:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField8(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 9:
      if fieldTypeId == thrift.MAP {
        if err := p.ReadField9(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *NotificationItem)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ID = v
}
  return nil
}

func (p *NotificationItem)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.From_ = v
}
  return nil
}

func (p *NotificationItem)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.To = v
}
  return nil
}

func (p *NotificationItem)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.FromChannel = v
}
  return nil
}

func (p *NotificationItem)  ReadField5(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 5: ", err)
} else {
  p.ToChannel = v
}
  return nil
}

func (p *NotificationItem)  ReadField7(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 7: ", err)
} else {
  p.Revision = v
}
  return nil
}

func (p *NotificationItem)  ReadField8(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 8: ", err)
} else {
  p.CreatedTime = v
}
  return nil
}

func (p *NotificationItem)  ReadField9(iprot thrift.TProtocol) error {
  _, _, size, err := iprot.ReadMapBegin()
  if err != nil {
    return thrift.PrependError("error reading map begin: ", err)
  }
  tMap := make(map[string]string, size)
  p.Content =  tMap
  for i := 0; i < size; i ++ {
var _key72 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _key72 = v
}
var _val73 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _val73 = v
}
    p.Content[_key72] = _val73
  }
  if err := iprot.ReadMapEnd(); err != nil {
    return thrift.PrependError("error reading map end: ", err)
  }
  return nil
}

func (p *NotificationItem) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("NotificationItem"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
    if err := p.writeField5(oprot); err != nil { return err }
    if err := p.writeField7(oprot); err != nil { return err }
    if err := p.writeField8(oprot); err != nil { return err }
    if err := p.writeField9(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *NotificationItem) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("id", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:id: ", p), err) }
  if err := oprot.WriteString(string(p.ID)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.id (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:id: ", p), err) }
  return err
}

func (p *NotificationItem) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("from_", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:from_: ", p), err) }
  if err := oprot.WriteString(string(p.From_)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.from_ (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:from_: ", p), err) }
  return err
}

func (p *NotificationItem) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("to", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:to: ", p), err) }
  if err := oprot.WriteString(string(p.To)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.to (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:to: ", p), err) }
  return err
}

func (p *NotificationItem) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("fromChannel", thrift.STRING, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:fromChannel: ", p), err) }
  if err := oprot.WriteString(string(p.FromChannel)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.fromChannel (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:fromChannel: ", p), err) }
  return err
}

func (p *NotificationItem) writeField5(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("toChannel", thrift.STRING, 5); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 5:toChannel: ", p), err) }
  if err := oprot.WriteString(string(p.ToChannel)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.toChannel (5) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 5:toChannel: ", p), err) }
  return err
}

func (p *NotificationItem) writeField7(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("revision", thrift.I64, 7); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 7:revision: ", p), err) }
  if err := oprot.WriteI64(int64(p.Revision)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.revision (7) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 7:revision: ", p), err) }
  return err
}

func (p *NotificationItem) writeField8(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("createdTime", thrift.I64, 8); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 8:createdTime: ", p), err) }
  if err := oprot.WriteI64(int64(p.CreatedTime)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.createdTime (8) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 8:createdTime: ", p), err) }
  return err
}

func (p *NotificationItem) writeField9(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("content", thrift.MAP, 9); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 9:content: ", p), err) }
  if err := oprot.WriteMapBegin(thrift.STRING, thrift.STRING, len(p.Content)); err != nil {
    return thrift.PrependError("error writing map begin: ", err)
  }
  for k, v := range p.Content {
    if err := oprot.WriteString(string(k)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
    if err := oprot.WriteString(string(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteMapEnd(); err != nil {
    return thrift.PrependError("error writing map end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 9:content: ", p), err) }
  return err
}

func (p *NotificationItem) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("NotificationItem(%+v)", *p)
}

type ApprovedChannelInfo struct {
  ChannelInfo *ChannelInfo `thrift:"channelInfo,1" db:"channelInfo" json:"channelInfo"`
  ApprovedAt int64 `thrift:"approvedAt,2" db:"approvedAt" json:"approvedAt"`
}

func NewApprovedChannelInfo() *ApprovedChannelInfo {
  return &ApprovedChannelInfo{}
}

var ApprovedChannelInfo_ChannelInfo_DEFAULT *ChannelInfo
func (p *ApprovedChannelInfo) GetChannelInfo() *ChannelInfo {
  if !p.IsSetChannelInfo() {
    return ApprovedChannelInfo_ChannelInfo_DEFAULT
  }
return p.ChannelInfo
}

func (p *ApprovedChannelInfo) GetApprovedAt() int64 {
  return p.ApprovedAt
}
func (p *ApprovedChannelInfo) IsSetChannelInfo() bool {
  return p.ChannelInfo != nil
}

func (p *ApprovedChannelInfo) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ApprovedChannelInfo)  ReadField1(iprot thrift.TProtocol) error {
  p.ChannelInfo = &ChannelInfo{}
  if err := p.ChannelInfo.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.ChannelInfo), err)
  }
  return nil
}

func (p *ApprovedChannelInfo)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ApprovedAt = v
}
  return nil
}

func (p *ApprovedChannelInfo) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ApprovedChannelInfo"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ApprovedChannelInfo) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelInfo", thrift.STRUCT, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelInfo: ", p), err) }
  if err := p.ChannelInfo.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.ChannelInfo), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelInfo: ", p), err) }
  return err
}

func (p *ApprovedChannelInfo) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("approvedAt", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:approvedAt: ", p), err) }
  if err := oprot.WriteI64(int64(p.ApprovedAt)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.approvedAt (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:approvedAt: ", p), err) }
  return err
}

func (p *ApprovedChannelInfo) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ApprovedChannelInfo(%+v)", *p)
}

// Attributes:
//  - ApprovedChannelInfos
//  - Revision
type ApprovedChannelInfos struct {
  ApprovedChannelInfos []*ApprovedChannelInfo `thrift:"approvedChannelInfos,1" db:"approvedChannelInfos" json:"approvedChannelInfos"`
  Revision int64 `thrift:"revision,2" db:"revision" json:"revision"`
}

func NewApprovedChannelInfos() *ApprovedChannelInfos {
  return &ApprovedChannelInfos{}
}


func (p *ApprovedChannelInfos) GetApprovedChannelInfos() []*ApprovedChannelInfo {
  return p.ApprovedChannelInfos
}

func (p *ApprovedChannelInfos) GetRevision() int64 {
  return p.Revision
}
func (p *ApprovedChannelInfos) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ApprovedChannelInfos)  ReadField1(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ApprovedChannelInfo, 0, size)
  p.ApprovedChannelInfos =  tSlice
  for i := 0; i < size; i ++ {
    _elem0 := &ApprovedChannelInfo{}
    if err := _elem0.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem0), err)
    }
    p.ApprovedChannelInfos = append(p.ApprovedChannelInfos, _elem0)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ApprovedChannelInfos)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Revision = v
}
  return nil
}

func (p *ApprovedChannelInfos) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ApprovedChannelInfos"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ApprovedChannelInfos) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("approvedChannelInfos", thrift.LIST, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:approvedChannelInfos: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ApprovedChannelInfos)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ApprovedChannelInfos {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:approvedChannelInfos: ", p), err) }
  return err
}

func (p *ApprovedChannelInfos) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("revision", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:revision: ", p), err) }
  if err := oprot.WriteI64(int64(p.Revision)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.revision (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:revision: ", p), err) }
  return err
}

func (p *ApprovedChannelInfos) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ApprovedChannelInfos(%+v)", *p)
}

type RequestTokenResponse struct {
  RequestToken string `thrift:"requestToken,1" db:"requestToken" json:"requestToken"`
  ReturnUrl string `thrift:"returnUrl,2" db:"returnUrl" json:"returnUrl"`
}

func NewRequestTokenResponse() *RequestTokenResponse {
  return &RequestTokenResponse{}
}


func (p *RequestTokenResponse) GetRequestToken() string {
  return p.RequestToken
}

func (p *RequestTokenResponse) GetReturnUrl() string {
  return p.ReturnUrl
}
func (p *RequestTokenResponse) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *RequestTokenResponse)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.RequestToken = v
}
  return nil
}

func (p *RequestTokenResponse)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ReturnUrl = v
}
  return nil
}

func (p *RequestTokenResponse) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("RequestTokenResponse"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *RequestTokenResponse) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("requestToken", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:requestToken: ", p), err) }
  if err := oprot.WriteString(string(p.RequestToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.requestToken (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:requestToken: ", p), err) }
  return err
}

func (p *RequestTokenResponse) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("returnUrl", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:returnUrl: ", p), err) }
  if err := oprot.WriteString(string(p.ReturnUrl)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.returnUrl (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:returnUrl: ", p), err) }
  return err
}

func (p *RequestTokenResponse) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("RequestTokenResponse(%+v)", *p)
}

type OTPResult_ struct {
  OtpId string `thrift:"otpId,1" db:"otpId" json:"otpId"`
  Otp string `thrift:"otp,2" db:"otp" json:"otp"`
}

func NewOTPResult_() *OTPResult_ {
  return &OTPResult_{}
}


func (p *OTPResult_) GetOtpId() string {
  return p.OtpId
}

func (p *OTPResult_) GetOtp() string {
  return p.Otp
}
func (p *OTPResult_) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *OTPResult_)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.OtpId = v
}
  return nil
}

func (p *OTPResult_)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Otp = v
}
  return nil
}

func (p *OTPResult_) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("OTPResult"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *OTPResult_) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("otpId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:otpId: ", p), err) }
  if err := oprot.WriteString(string(p.OtpId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.otpId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:otpId: ", p), err) }
  return err
}

func (p *OTPResult_) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("otp", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:otp: ", p), err) }
  if err := oprot.WriteString(string(p.Otp)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.otp (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:otp: ", p), err) }
  return err
}

func (p *OTPResult_) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("OTPResult_(%+v)", *p)
}

type PublicType int64
const (
  PublicType_HIDDEN PublicType = 0
  PublicType_PUBLIC PublicType = 1000
)

func (p PublicType) String() string {
  switch p {
  case PublicType_HIDDEN: return "HIDDEN"
  case PublicType_PUBLIC: return "PUBLIC"
  }
  return "<UNSET>"
}

func PublicTypeFromString(s string) (PublicType, error) {
  switch s {
  case "HIDDEN": return PublicType_HIDDEN, nil 
  case "PUBLIC": return PublicType_PUBLIC, nil 
  }
  return PublicType(0), fmt.Errorf("not a valid PublicType string")
}


func PublicTypePtr(v PublicType) *PublicType { return &v }

func (p PublicType) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *PublicType) UnmarshalText(text []byte) error {
q, err := PublicTypeFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *PublicType) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = PublicType(v)
return nil
}

func (p * PublicType) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}
type RedirectType int64
const (
  RedirectType_NONE RedirectType = 0
  RedirectType_EXPIRE_SECOND RedirectType = 1
)

func (p RedirectType) String() string {
  switch p {
  case RedirectType_NONE: return "NONE"
  case RedirectType_EXPIRE_SECOND: return "EXPIRE_SECOND"
  }
  return "<UNSET>"
}

func RedirectTypeFromString(s string) (RedirectType, error) {
  switch s {
  case "NONE": return RedirectType_NONE, nil 
  case "EXPIRE_SECOND": return RedirectType_EXPIRE_SECOND, nil 
  }
  return RedirectType(0), fmt.Errorf("not a valid RedirectType string")
}


func RedirectTypePtr(v RedirectType) *RedirectType { return &v }

func (p RedirectType) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *RedirectType) UnmarshalText(text []byte) error {
q, err := RedirectTypeFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *RedirectType) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = RedirectType(v)
return nil
}

func (p * RedirectType) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}

type ChannelConfiguration int64
const (
  ChannelConfiguration_MESSAGE ChannelConfiguration = 0
  ChannelConfiguration_MESSAGE_NOTIFICATION ChannelConfiguration = 1
  ChannelConfiguration_NOTIFICATION_CENTER ChannelConfiguration = 2
)

func (p ChannelConfiguration) String() string {
  switch p {
  case ChannelConfiguration_MESSAGE: return "MESSAGE"
  case ChannelConfiguration_MESSAGE_NOTIFICATION: return "MESSAGE_NOTIFICATION"
  case ChannelConfiguration_NOTIFICATION_CENTER: return "NOTIFICATION_CENTER"
  }
  return "<UNSET>"
}

func ChannelConfigurationFromString(s string) (ChannelConfiguration, error) {
  switch s {
  case "MESSAGE": return ChannelConfiguration_MESSAGE, nil 
  case "MESSAGE_NOTIFICATION": return ChannelConfiguration_MESSAGE_NOTIFICATION, nil 
  case "NOTIFICATION_CENTER": return ChannelConfiguration_NOTIFICATION_CENTER, nil 
  }
  return ChannelConfiguration(0), fmt.Errorf("not a valid ChannelConfiguration string")
}


func ChannelConfigurationPtr(v ChannelConfiguration) *ChannelConfiguration { return &v }

func (p ChannelConfiguration) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *ChannelConfiguration) UnmarshalText(text []byte) error {
q, err := ChannelConfigurationFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *ChannelConfiguration) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = ChannelConfiguration(v)
return nil
}

func (p * ChannelConfiguration) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}
type ChannelErrorCode int64
const (
  ChannelErrorCode_ILLEGAL_ARGUMENT ChannelErrorCode = 0
  ChannelErrorCode_INTERNAL_ERROR ChannelErrorCode = 1
  ChannelErrorCode_CONNECTION_ERROR ChannelErrorCode = 2
  ChannelErrorCode_AUTHENTICATIONI_FAILED ChannelErrorCode = 3
  ChannelErrorCode_NEED_PERMISSION_APPROVAL ChannelErrorCode = 4
  ChannelErrorCode_COIN_NOT_USABLE ChannelErrorCode = 5
  ChannelErrorCode_WEBVIEW_NOT_ALLOWED ChannelErrorCode = 6
)

func (p ChannelErrorCode) String() string {
  switch p {
  case ChannelErrorCode_ILLEGAL_ARGUMENT: return "ILLEGAL_ARGUMENT"
  case ChannelErrorCode_INTERNAL_ERROR: return "INTERNAL_ERROR"
  case ChannelErrorCode_CONNECTION_ERROR: return "CONNECTION_ERROR"
  case ChannelErrorCode_AUTHENTICATIONI_FAILED: return "AUTHENTICATIONI_FAILED"
  case ChannelErrorCode_NEED_PERMISSION_APPROVAL: return "NEED_PERMISSION_APPROVAL"
  case ChannelErrorCode_COIN_NOT_USABLE: return "COIN_NOT_USABLE"
  case ChannelErrorCode_WEBVIEW_NOT_ALLOWED: return "WEBVIEW_NOT_ALLOWED"
  }
  return "<UNSET>"
}

func ChannelErrorCodeFromString(s string) (ChannelErrorCode, error) {
  switch s {
  case "ILLEGAL_ARGUMENT": return ChannelErrorCode_ILLEGAL_ARGUMENT, nil 
  case "INTERNAL_ERROR": return ChannelErrorCode_INTERNAL_ERROR, nil 
  case "CONNECTION_ERROR": return ChannelErrorCode_CONNECTION_ERROR, nil 
  case "AUTHENTICATIONI_FAILED": return ChannelErrorCode_AUTHENTICATIONI_FAILED, nil 
  case "NEED_PERMISSION_APPROVAL": return ChannelErrorCode_NEED_PERMISSION_APPROVAL, nil 
  case "COIN_NOT_USABLE": return ChannelErrorCode_COIN_NOT_USABLE, nil 
  case "WEBVIEW_NOT_ALLOWED": return ChannelErrorCode_WEBVIEW_NOT_ALLOWED, nil 
  }
  return ChannelErrorCode(0), fmt.Errorf("not a valid ChannelErrorCode string")
}


func ChannelErrorCodePtr(v ChannelErrorCode) *ChannelErrorCode { return &v }

func (p ChannelErrorCode) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *ChannelErrorCode) UnmarshalText(text []byte) error {
q, err := ChannelErrorCodeFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *ChannelErrorCode) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = ChannelErrorCode(v)
return nil
}

func (p * ChannelErrorCode) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}
type ChannelPermission int64
const (
  ChannelPermission_PROFILE ChannelPermission = 0
  ChannelPermission_FRIENDS ChannelPermission = 1
  ChannelPermission_GROUP ChannelPermission = 2
)

func (p ChannelPermission) String() string {
  switch p {
  case ChannelPermission_PROFILE: return "PROFILE"
  case ChannelPermission_FRIENDS: return "FRIENDS"
  case ChannelPermission_GROUP: return "GROUP"
  }
  return "<UNSET>"
}

func ChannelPermissionFromString(s string) (ChannelPermission, error) {
  switch s {
  case "PROFILE": return ChannelPermission_PROFILE, nil 
  case "FRIENDS": return ChannelPermission_FRIENDS, nil 
  case "GROUP": return ChannelPermission_GROUP, nil 
  }
  return ChannelPermission(0), fmt.Errorf("not a valid ChannelPermission string")
}


func ChannelPermissionPtr(v ChannelPermission) *ChannelPermission { return &v }

func (p ChannelPermission) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *ChannelPermission) UnmarshalText(text []byte) error {
q, err := ChannelPermissionFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *ChannelPermission) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = ChannelPermission(v)
return nil
}

func (p * ChannelPermission) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}
type ChannelSyncTarget int64
const (
  ChannelSyncTarget_ALL ChannelSyncTarget = 255
  ChannelSyncTarget_CHANNEL_INFO ChannelSyncTarget = 1
  ChannelSyncTarget_CHANNEL_TOKEN ChannelSyncTarget = 2
  ChannelSyncTarget_COMMON_DOMAIN ChannelSyncTarget = 4
)

func (p ChannelSyncTarget) String() string {
  switch p {
  case ChannelSyncTarget_ALL: return "ALL"
  case ChannelSyncTarget_CHANNEL_INFO: return "CHANNEL_INFO"
  case ChannelSyncTarget_CHANNEL_TOKEN: return "CHANNEL_TOKEN"
  case ChannelSyncTarget_COMMON_DOMAIN: return "COMMON_DOMAIN"
  }
  return "<UNSET>"
}

func ChannelSyncTargetFromString(s string) (ChannelSyncTarget, error) {
  switch s {
  case "ALL": return ChannelSyncTarget_ALL, nil 
  case "CHANNEL_INFO": return ChannelSyncTarget_CHANNEL_INFO, nil 
  case "CHANNEL_TOKEN": return ChannelSyncTarget_CHANNEL_TOKEN, nil 
  case "COMMON_DOMAIN": return ChannelSyncTarget_COMMON_DOMAIN, nil 
  }
  return ChannelSyncTarget(0), fmt.Errorf("not a valid ChannelSyncTarget string")
}


func ChannelSyncTargetPtr(v ChannelSyncTarget) *ChannelSyncTarget { return &v }

func (p ChannelSyncTarget) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *ChannelSyncTarget) UnmarshalText(text []byte) error {
q, err := ChannelSyncTargetFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *ChannelSyncTarget) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = ChannelSyncTarget(v)
return nil
}

func (p * ChannelSyncTarget) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}
type ChannelSyncType int64
const (
  ChannelSyncType_SYNC ChannelSyncType = 0
  ChannelSyncType_REMOVE ChannelSyncType = 1
  ChannelSyncType_REMOVE_ALL ChannelSyncType = 2
)

func (p ChannelSyncType) String() string {
  switch p {
  case ChannelSyncType_SYNC: return "SYNC"
  case ChannelSyncType_REMOVE: return "REMOVE"
  case ChannelSyncType_REMOVE_ALL: return "REMOVE_ALL"
  }
  return "<UNSET>"
}

func ChannelSyncTypeFromString(s string) (ChannelSyncType, error) {
  switch s {
  case "SYNC": return ChannelSyncType_SYNC, nil 
  case "REMOVE": return ChannelSyncType_REMOVE, nil 
  case "REMOVE_ALL": return ChannelSyncType_REMOVE_ALL, nil 
  }
  return ChannelSyncType(0), fmt.Errorf("not a valid ChannelSyncType string")
}


func ChannelSyncTypePtr(v ChannelSyncType) *ChannelSyncType { return &v }

func (p ChannelSyncType) MarshalText() ([]byte, error) {
return []byte(p.String()), nil
}

func (p *ChannelSyncType) UnmarshalText(text []byte) error {
q, err := ChannelSyncTypeFromString(string(text))
if (err != nil) {
return err
}
*p = q
return nil
}

func (p *ChannelSyncType) Scan(value interface{}) error {
v, ok := value.(int64)
if !ok {
return errors.New("Scan value is not int64")
}
*p = ChannelSyncType(v)
return nil
}

func (p * ChannelSyncType) Value() (driver.Value, error) {
  if p == nil {
    return nil, nil
  }
return int64(*p), nil
}

type ChannelDomain struct {
  Host string `thrift:"host,1" db:"host" json:"host"`
  Removed bool `thrift:"removed,2" db:"removed" json:"removed"`
}

func NewChannelDomain() *ChannelDomain {
  return &ChannelDomain{}
}


func (p *ChannelDomain) GetHost() string {
  return p.Host
}

func (p *ChannelDomain) GetRemoved() bool {
  return p.Removed
}
func (p *ChannelDomain) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelDomain)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.Host = v
}
  return nil
}

func (p *ChannelDomain)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Removed = v
}
  return nil
}

func (p *ChannelDomain) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelDomain"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelDomain) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("host", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:host: ", p), err) }
  if err := oprot.WriteString(string(p.Host)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.host (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:host: ", p), err) }
  return err
}

func (p *ChannelDomain) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("removed", thrift.BOOL, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:removed: ", p), err) }
  if err := oprot.WriteBool(bool(p.Removed)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.removed (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:removed: ", p), err) }
  return err
}

func (p *ChannelDomain) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelDomain(%+v)", *p)
}

// Attributes:
//  - ChannelDomains
//  - Revision
type ChannelDomains struct {
  ChannelDomains []*ChannelDomain `thrift:"channelDomains,1" db:"channelDomains" json:"channelDomains"`
  Revision int64 `thrift:"revision,2" db:"revision" json:"revision"`
}

func NewChannelDomains() *ChannelDomains {
  return &ChannelDomains{}
}


func (p *ChannelDomains) GetChannelDomains() []*ChannelDomain {
  return p.ChannelDomains
}

func (p *ChannelDomains) GetRevision() int64 {
  return p.Revision
}
func (p *ChannelDomains) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelDomains)  ReadField1(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelDomain, 0, size)
  p.ChannelDomains =  tSlice
  for i := 0; i < size; i ++ {
    _elem26 := &ChannelDomain{}
    if err := _elem26.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem26), err)
    }
    p.ChannelDomains = append(p.ChannelDomains, _elem26)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelDomains)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Revision = v
}
  return nil
}

func (p *ChannelDomains) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelDomains"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelDomains) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelDomains", thrift.LIST, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelDomains: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ChannelDomains)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelDomains {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelDomains: ", p), err) }
  return err
}

func (p *ChannelDomains) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("revision", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:revision: ", p), err) }
  if err := oprot.WriteI64(int64(p.Revision)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.revision (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:revision: ", p), err) }
  return err
}

func (p *ChannelDomains) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelDomains(%+v)", *p)
}

// Attributes:
//  - Code
//  - Reason
//  - ParameterMap
type ChannelException struct {
  Code ChannelErrorCode `thrift:"code,1" db:"code" json:"code"`
  Reason string `thrift:"reason,2" db:"reason" json:"reason"`
  ParameterMap map[string]string `thrift:"parameterMap,3" db:"parameterMap" json:"parameterMap"`
}

func NewChannelException() *ChannelException {
  return &ChannelException{}
}


func (p *ChannelException) GetCode() ChannelErrorCode {
  return p.Code
}

func (p *ChannelException) GetReason() string {
  return p.Reason
}

func (p *ChannelException) GetParameterMap() map[string]string {
  return p.ParameterMap
}
func (p *ChannelException) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.MAP {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelException)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  temp := ChannelErrorCode(v)
  p.Code = temp
}
  return nil
}

func (p *ChannelException)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Reason = v
}
  return nil
}

func (p *ChannelException)  ReadField3(iprot thrift.TProtocol) error {
  _, _, size, err := iprot.ReadMapBegin()
  if err != nil {
    return thrift.PrependError("error reading map begin: ", err)
  }
  tMap := make(map[string]string, size)
  p.ParameterMap =  tMap
  for i := 0; i < size; i ++ {
var _key27 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _key27 = v
}
var _val28 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _val28 = v
}
    p.ParameterMap[_key27] = _val28
  }
  if err := iprot.ReadMapEnd(); err != nil {
    return thrift.PrependError("error reading map end: ", err)
  }
  return nil
}

func (p *ChannelException) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelException"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelException) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("code", thrift.I32, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:code: ", p), err) }
  if err := oprot.WriteI32(int32(p.Code)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.code (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:code: ", p), err) }
  return err
}

func (p *ChannelException) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("reason", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:reason: ", p), err) }
  if err := oprot.WriteString(string(p.Reason)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.reason (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:reason: ", p), err) }
  return err
}

func (p *ChannelException) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("parameterMap", thrift.MAP, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:parameterMap: ", p), err) }
  if err := oprot.WriteMapBegin(thrift.STRING, thrift.STRING, len(p.ParameterMap)); err != nil {
    return thrift.PrependError("error writing map begin: ", err)
  }
  for k, v := range p.ParameterMap {
    if err := oprot.WriteString(string(k)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
    if err := oprot.WriteString(string(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteMapEnd(); err != nil {
    return thrift.PrependError("error writing map end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:parameterMap: ", p), err) }
  return err
}

func (p *ChannelException) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelException(%+v)", *p)
}

func (p *ChannelException) Error() string {
  return p.String()
}

// Attributes:
//  - ChannelId
//  - LastUpdated
type ChannelIdWithLastUpdated struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  LastUpdated int64 `thrift:"lastUpdated,2" db:"lastUpdated" json:"lastUpdated"`
}

func NewChannelIdWithLastUpdated() *ChannelIdWithLastUpdated {
  return &ChannelIdWithLastUpdated{}
}


func (p *ChannelIdWithLastUpdated) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelIdWithLastUpdated) GetLastUpdated() int64 {
  return p.LastUpdated
}
func (p *ChannelIdWithLastUpdated) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelIdWithLastUpdated)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelIdWithLastUpdated)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.LastUpdated = v
}
  return nil
}

func (p *ChannelIdWithLastUpdated) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelIdWithLastUpdated"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelIdWithLastUpdated) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelIdWithLastUpdated) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("lastUpdated", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:lastUpdated: ", p), err) }
  if err := oprot.WriteI64(int64(p.LastUpdated)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.lastUpdated (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:lastUpdated: ", p), err) }
  return err
}

func (p *ChannelIdWithLastUpdated) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelIdWithLastUpdated(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - Name
//  - EntryPageUrl
//  - DescriptionText
//  - Provider
//  - PublicType
//  - IconImage
//  - Permissions
//  - IconThumbnailImage
//  - ChannelConfigurations
//  - LcsAllApiUsable
//  - AllowedPermissions
//  - ChannelDomains
//  - UpdatedTimestamp
type ChannelInfo struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  // unused field # 2
  Name string `thrift:"name,3" db:"name" json:"name"`
  EntryPageUrl string `thrift:"entryPageUrl,4" db:"entryPageUrl" json:"entryPageUrl"`
  DescriptionText string `thrift:"descriptionText,5" db:"descriptionText" json:"descriptionText"`
  Provider *ChannelProvider `thrift:"provider,6" db:"provider" json:"provider"`
  PublicType PublicType `thrift:"publicType,7" db:"publicType" json:"publicType"`
  IconImage string `thrift:"iconImage,8" db:"iconImage" json:"iconImage"`
  Permissions []string `thrift:"permissions,9" db:"permissions" json:"permissions"`
  // unused field # 10
  IconThumbnailImage string `thrift:"iconThumbnailImage,11" db:"iconThumbnailImage" json:"iconThumbnailImage"`
  ChannelConfigurations []ChannelConfiguration `thrift:"channelConfigurations,12" db:"channelConfigurations" json:"channelConfigurations"`
  LcsAllApiUsable bool `thrift:"lcsAllApiUsable,13" db:"lcsAllApiUsable" json:"lcsAllApiUsable"`
  AllowedPermissions []ChannelPermission `thrift:"allowedPermissions,14" db:"allowedPermissions" json:"allowedPermissions"`
  ChannelDomains []*ChannelDomain `thrift:"channelDomains,15" db:"channelDomains" json:"channelDomains"`
  UpdatedTimestamp int64 `thrift:"updatedTimestamp,16" db:"updatedTimestamp" json:"updatedTimestamp"`
}

func NewChannelInfo() *ChannelInfo {
  return &ChannelInfo{}
}


func (p *ChannelInfo) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelInfo) GetName() string {
  return p.Name
}

func (p *ChannelInfo) GetEntryPageUrl() string {
  return p.EntryPageUrl
}

func (p *ChannelInfo) GetDescriptionText() string {
  return p.DescriptionText
}
var ChannelInfo_Provider_DEFAULT *ChannelProvider
func (p *ChannelInfo) GetProvider() *ChannelProvider {
  if !p.IsSetProvider() {
    return ChannelInfo_Provider_DEFAULT
  }
return p.Provider
}

func (p *ChannelInfo) GetPublicType() PublicType {
  return p.PublicType
}

func (p *ChannelInfo) GetIconImage() string {
  return p.IconImage
}

func (p *ChannelInfo) GetPermissions() []string {
  return p.Permissions
}

func (p *ChannelInfo) GetIconThumbnailImage() string {
  return p.IconThumbnailImage
}

func (p *ChannelInfo) GetChannelConfigurations() []ChannelConfiguration {
  return p.ChannelConfigurations
}

func (p *ChannelInfo) GetLcsAllApiUsable() bool {
  return p.LcsAllApiUsable
}

func (p *ChannelInfo) GetAllowedPermissions() []ChannelPermission {
  return p.AllowedPermissions
}

func (p *ChannelInfo) GetChannelDomains() []*ChannelDomain {
  return p.ChannelDomains
}

func (p *ChannelInfo) GetUpdatedTimestamp() int64 {
  return p.UpdatedTimestamp
}
func (p *ChannelInfo) IsSetProvider() bool {
  return p.Provider != nil
}

func (p *ChannelInfo) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 5:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField5(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 6:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField6(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 7:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField7(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 8:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField8(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 9:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField9(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 11:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField11(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 12:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField12(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 13:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField13(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 14:
      if fieldTypeId == thrift.SET {
        if err := p.ReadField14(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 15:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField15(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 16:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField16(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelInfo)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelInfo)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Name = v
}
  return nil
}

func (p *ChannelInfo)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.EntryPageUrl = v
}
  return nil
}

func (p *ChannelInfo)  ReadField5(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 5: ", err)
} else {
  p.DescriptionText = v
}
  return nil
}

func (p *ChannelInfo)  ReadField6(iprot thrift.TProtocol) error {
  p.Provider = &ChannelProvider{}
  if err := p.Provider.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Provider), err)
  }
  return nil
}

func (p *ChannelInfo)  ReadField7(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 7: ", err)
} else {
  temp := PublicType(v)
  p.PublicType = temp
}
  return nil
}

func (p *ChannelInfo)  ReadField8(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 8: ", err)
} else {
  p.IconImage = v
}
  return nil
}

func (p *ChannelInfo)  ReadField9(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]string, 0, size)
  p.Permissions =  tSlice
  for i := 0; i < size; i ++ {
var _elem29 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _elem29 = v
}
    p.Permissions = append(p.Permissions, _elem29)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelInfo)  ReadField11(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 11: ", err)
} else {
  p.IconThumbnailImage = v
}
  return nil
}

func (p *ChannelInfo)  ReadField12(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]ChannelConfiguration, 0, size)
  p.ChannelConfigurations =  tSlice
  for i := 0; i < size; i ++ {
var _elem30 ChannelConfiguration
    if v, err := iprot.ReadI32(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    temp := ChannelConfiguration(v)
    _elem30 = temp
}
    p.ChannelConfigurations = append(p.ChannelConfigurations, _elem30)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelInfo)  ReadField13(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 13: ", err)
} else {
  p.LcsAllApiUsable = v
}
  return nil
}

func (p *ChannelInfo)  ReadField14(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadSetBegin()
  if err != nil {
    return thrift.PrependError("error reading set begin: ", err)
  }
  tSet := make([]ChannelPermission, 0, size)
  p.AllowedPermissions =  tSet
  for i := 0; i < size; i ++ {
var _elem31 ChannelPermission
    if v, err := iprot.ReadI32(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    temp := ChannelPermission(v)
    _elem31 = temp
}
    p.AllowedPermissions = append(p.AllowedPermissions, _elem31)
  }
  if err := iprot.ReadSetEnd(); err != nil {
    return thrift.PrependError("error reading set end: ", err)
  }
  return nil
}

func (p *ChannelInfo)  ReadField15(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelDomain, 0, size)
  p.ChannelDomains =  tSlice
  for i := 0; i < size; i ++ {
    _elem32 := &ChannelDomain{}
    if err := _elem32.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem32), err)
    }
    p.ChannelDomains = append(p.ChannelDomains, _elem32)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelInfo)  ReadField16(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 16: ", err)
} else {
  p.UpdatedTimestamp = v
}
  return nil
}

func (p *ChannelInfo) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelInfo"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
    if err := p.writeField5(oprot); err != nil { return err }
    if err := p.writeField6(oprot); err != nil { return err }
    if err := p.writeField7(oprot); err != nil { return err }
    if err := p.writeField8(oprot); err != nil { return err }
    if err := p.writeField9(oprot); err != nil { return err }
    if err := p.writeField11(oprot); err != nil { return err }
    if err := p.writeField12(oprot); err != nil { return err }
    if err := p.writeField13(oprot); err != nil { return err }
    if err := p.writeField14(oprot); err != nil { return err }
    if err := p.writeField15(oprot); err != nil { return err }
    if err := p.writeField16(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelInfo) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("name", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:name: ", p), err) }
  if err := oprot.WriteString(string(p.Name)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.name (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:name: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("entryPageUrl", thrift.STRING, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:entryPageUrl: ", p), err) }
  if err := oprot.WriteString(string(p.EntryPageUrl)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.entryPageUrl (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:entryPageUrl: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField5(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("descriptionText", thrift.STRING, 5); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 5:descriptionText: ", p), err) }
  if err := oprot.WriteString(string(p.DescriptionText)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.descriptionText (5) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 5:descriptionText: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField6(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("provider", thrift.STRUCT, 6); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 6:provider: ", p), err) }
  if err := p.Provider.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Provider), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 6:provider: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField7(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("publicType", thrift.I32, 7); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 7:publicType: ", p), err) }
  if err := oprot.WriteI32(int32(p.PublicType)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.publicType (7) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 7:publicType: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField8(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("iconImage", thrift.STRING, 8); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 8:iconImage: ", p), err) }
  if err := oprot.WriteString(string(p.IconImage)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.iconImage (8) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 8:iconImage: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField9(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("permissions", thrift.LIST, 9); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 9:permissions: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRING, len(p.Permissions)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.Permissions {
    if err := oprot.WriteString(string(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 9:permissions: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField11(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("iconThumbnailImage", thrift.STRING, 11); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 11:iconThumbnailImage: ", p), err) }
  if err := oprot.WriteString(string(p.IconThumbnailImage)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.iconThumbnailImage (11) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 11:iconThumbnailImage: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField12(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelConfigurations", thrift.LIST, 12); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 12:channelConfigurations: ", p), err) }
  if err := oprot.WriteListBegin(thrift.I32, len(p.ChannelConfigurations)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelConfigurations {
    if err := oprot.WriteI32(int32(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 12:channelConfigurations: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField13(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("lcsAllApiUsable", thrift.BOOL, 13); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 13:lcsAllApiUsable: ", p), err) }
  if err := oprot.WriteBool(bool(p.LcsAllApiUsable)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.lcsAllApiUsable (13) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 13:lcsAllApiUsable: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField14(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("allowedPermissions", thrift.SET, 14); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 14:allowedPermissions: ", p), err) }
  if err := oprot.WriteSetBegin(thrift.I32, len(p.AllowedPermissions)); err != nil {
    return thrift.PrependError("error writing set begin: ", err)
  }
  for i := 0; i<len(p.AllowedPermissions); i++ {
    for j := i+1; j<len(p.AllowedPermissions); j++ {
      if reflect.DeepEqual(p.AllowedPermissions[i],p.AllowedPermissions[j]) { 
        return thrift.PrependError("", fmt.Errorf("%T error writing set field: slice is not unique", p.AllowedPermissions[i]))
      }
    }
  }
  for _, v := range p.AllowedPermissions {
    if err := oprot.WriteI32(int32(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteSetEnd(); err != nil {
    return thrift.PrependError("error writing set end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 14:allowedPermissions: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField15(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelDomains", thrift.LIST, 15); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 15:channelDomains: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ChannelDomains)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelDomains {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 15:channelDomains: ", p), err) }
  return err
}

func (p *ChannelInfo) writeField16(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("updatedTimestamp", thrift.I64, 16); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 16:updatedTimestamp: ", p), err) }
  if err := oprot.WriteI64(int64(p.UpdatedTimestamp)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.updatedTimestamp (16) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 16:updatedTimestamp: ", p), err) }
  return err
}

func (p *ChannelInfo) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelInfo(%+v)", *p)
}

// Attributes:
//  - ChannelInfos
//  - Revision
type ChannelInfos struct {
  ChannelInfos []*ChannelInfo `thrift:"channelInfos,1" db:"channelInfos" json:"channelInfos"`
  Revision int64 `thrift:"revision,2" db:"revision" json:"revision"`
}

func NewChannelInfos() *ChannelInfos {
  return &ChannelInfos{}
}


func (p *ChannelInfos) GetChannelInfos() []*ChannelInfo {
  return p.ChannelInfos
}

func (p *ChannelInfos) GetRevision() int64 {
  return p.Revision
}
func (p *ChannelInfos) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelInfos)  ReadField1(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelInfo, 0, size)
  p.ChannelInfos =  tSlice
  for i := 0; i < size; i ++ {
    _elem33 := &ChannelInfo{}
    if err := _elem33.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem33), err)
    }
    p.ChannelInfos = append(p.ChannelInfos, _elem33)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelInfos)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Revision = v
}
  return nil
}

func (p *ChannelInfos) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelInfos"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelInfos) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelInfos", thrift.LIST, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelInfos: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ChannelInfos)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelInfos {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelInfos: ", p), err) }
  return err
}

func (p *ChannelInfos) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("revision", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:revision: ", p), err) }
  if err := oprot.WriteI64(int64(p.Revision)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.revision (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:revision: ", p), err) }
  return err
}

func (p *ChannelInfos) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelInfos(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - Name
//  - NotificationReceivable
//  - MessageReceivable
//  - ShowDefault
type ChannelNotificationSetting struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  Name string `thrift:"name,2" db:"name" json:"name"`
  NotificationReceivable bool `thrift:"notificationReceivable,3" db:"notificationReceivable" json:"notificationReceivable"`
  MessageReceivable bool `thrift:"messageReceivable,4" db:"messageReceivable" json:"messageReceivable"`
  ShowDefault bool `thrift:"showDefault,5" db:"showDefault" json:"showDefault"`
}

func NewChannelNotificationSetting() *ChannelNotificationSetting {
  return &ChannelNotificationSetting{}
}


func (p *ChannelNotificationSetting) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelNotificationSetting) GetName() string {
  return p.Name
}

func (p *ChannelNotificationSetting) GetNotificationReceivable() bool {
  return p.NotificationReceivable
}

func (p *ChannelNotificationSetting) GetMessageReceivable() bool {
  return p.MessageReceivable
}

func (p *ChannelNotificationSetting) GetShowDefault() bool {
  return p.ShowDefault
}
func (p *ChannelNotificationSetting) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 5:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField5(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelNotificationSetting)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelNotificationSetting)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Name = v
}
  return nil
}

func (p *ChannelNotificationSetting)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.NotificationReceivable = v
}
  return nil
}

func (p *ChannelNotificationSetting)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.MessageReceivable = v
}
  return nil
}

func (p *ChannelNotificationSetting)  ReadField5(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 5: ", err)
} else {
  p.ShowDefault = v
}
  return nil
}

func (p *ChannelNotificationSetting) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelNotificationSetting"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
    if err := p.writeField5(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelNotificationSetting) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelNotificationSetting) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("name", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:name: ", p), err) }
  if err := oprot.WriteString(string(p.Name)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.name (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:name: ", p), err) }
  return err
}

func (p *ChannelNotificationSetting) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("notificationReceivable", thrift.BOOL, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:notificationReceivable: ", p), err) }
  if err := oprot.WriteBool(bool(p.NotificationReceivable)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.notificationReceivable (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:notificationReceivable: ", p), err) }
  return err
}

func (p *ChannelNotificationSetting) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("messageReceivable", thrift.BOOL, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:messageReceivable: ", p), err) }
  if err := oprot.WriteBool(bool(p.MessageReceivable)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.messageReceivable (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:messageReceivable: ", p), err) }
  return err
}

func (p *ChannelNotificationSetting) writeField5(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("showDefault", thrift.BOOL, 5); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 5:showDefault: ", p), err) }
  if err := oprot.WriteBool(bool(p.ShowDefault)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.showDefault (5) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 5:showDefault: ", p), err) }
  return err
}

func (p *ChannelNotificationSetting) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelNotificationSetting(%+v)", *p)
}

// Attributes:
//  - Name
type ChannelProvider struct {
  Name string `thrift:"name,1" db:"name" json:"name"`
}

func NewChannelProvider() *ChannelProvider {
  return &ChannelProvider{}
}


func (p *ChannelProvider) GetName() string {
  return p.Name
}
func (p *ChannelProvider) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelProvider)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.Name = v
}
  return nil
}

func (p *ChannelProvider) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelProvider"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelProvider) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("name", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:name: ", p), err) }
  if err := oprot.WriteString(string(p.Name)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.name (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:name: ", p), err) }
  return err
}

func (p *ChannelProvider) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelProvider(%+v)", *p)
}

// Attributes:
//  - UnapprovedMessageReceivable
type ChannelSettings struct {
  UnapprovedMessageReceivable bool `thrift:"unapprovedMessageReceivable,1" db:"unapprovedMessageReceivable" json:"unapprovedMessageReceivable"`
}

func NewChannelSettings() *ChannelSettings {
  return &ChannelSettings{}
}


func (p *ChannelSettings) GetUnapprovedMessageReceivable() bool {
  return p.UnapprovedMessageReceivable
}
func (p *ChannelSettings) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelSettings)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.UnapprovedMessageReceivable = v
}
  return nil
}

func (p *ChannelSettings) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelSettings"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelSettings) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("unapprovedMessageReceivable", thrift.BOOL, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:unapprovedMessageReceivable: ", p), err) }
  if err := oprot.WriteBool(bool(p.UnapprovedMessageReceivable)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.unapprovedMessageReceivable (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:unapprovedMessageReceivable: ", p), err) }
  return err
}

func (p *ChannelSettings) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelSettings(%+v)", *p)
}

// Attributes:
//  - ChannelInfos
//  - ChannelDomains
//  - Revision
//  - Expires
type ChannelSyncDatas struct {
  ChannelInfos []*ChannelInfo `thrift:"channelInfos,1" db:"channelInfos" json:"channelInfos"`
  ChannelDomains []*ChannelDomain `thrift:"channelDomains,2" db:"channelDomains" json:"channelDomains"`
  Revision int64 `thrift:"revision,3" db:"revision" json:"revision"`
  Expires int64 `thrift:"expires,4" db:"expires" json:"expires"`
}

func NewChannelSyncDatas() *ChannelSyncDatas {
  return &ChannelSyncDatas{}
}


func (p *ChannelSyncDatas) GetChannelInfos() []*ChannelInfo {
  return p.ChannelInfos
}

func (p *ChannelSyncDatas) GetChannelDomains() []*ChannelDomain {
  return p.ChannelDomains
}

func (p *ChannelSyncDatas) GetRevision() int64 {
  return p.Revision
}

func (p *ChannelSyncDatas) GetExpires() int64 {
  return p.Expires
}
func (p *ChannelSyncDatas) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelSyncDatas)  ReadField1(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelInfo, 0, size)
  p.ChannelInfos =  tSlice
  for i := 0; i < size; i ++ {
    _elem34 := &ChannelInfo{}
    if err := _elem34.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem34), err)
    }
    p.ChannelInfos = append(p.ChannelInfos, _elem34)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelSyncDatas)  ReadField2(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelDomain, 0, size)
  p.ChannelDomains =  tSlice
  for i := 0; i < size; i ++ {
    _elem35 := &ChannelDomain{}
    if err := _elem35.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem35), err)
    }
    p.ChannelDomains = append(p.ChannelDomains, _elem35)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelSyncDatas)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Revision = v
}
  return nil
}

func (p *ChannelSyncDatas)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.Expires = v
}
  return nil
}

func (p *ChannelSyncDatas) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelSyncDatas"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelSyncDatas) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelInfos", thrift.LIST, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelInfos: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ChannelInfos)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelInfos {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelInfos: ", p), err) }
  return err
}

func (p *ChannelSyncDatas) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelDomains", thrift.LIST, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:channelDomains: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ChannelDomains)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelDomains {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:channelDomains: ", p), err) }
  return err
}

func (p *ChannelSyncDatas) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("revision", thrift.I64, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:revision: ", p), err) }
  if err := oprot.WriteI64(int64(p.Revision)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.revision (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:revision: ", p), err) }
  return err
}

func (p *ChannelSyncDatas) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("expires", thrift.I64, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:expires: ", p), err) }
  if err := oprot.WriteI64(int64(p.Expires)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.expires (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:expires: ", p), err) }
  return err
}

func (p *ChannelSyncDatas) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelSyncDatas(%+v)", *p)
}

// Attributes:
//  - Token
//  - ObsToken
//  - Expiration
//  - RefreshToken
//  - ChannelAccessToken
type ChannelToken struct {
  Token string `thrift:"token,1" db:"token" json:"token"`
  ObsToken string `thrift:"obsToken,2" db:"obsToken" json:"obsToken"`
  Expiration int64 `thrift:"expiration,3" db:"expiration" json:"expiration"`
  RefreshToken string `thrift:"refreshToken,4" db:"refreshToken" json:"refreshToken"`
  ChannelAccessToken string `thrift:"channelAccessToken,5" db:"channelAccessToken" json:"channelAccessToken"`
}

func NewChannelToken() *ChannelToken {
  return &ChannelToken{}
}


func (p *ChannelToken) GetToken() string {
  return p.Token
}

func (p *ChannelToken) GetObsToken() string {
  return p.ObsToken
}

func (p *ChannelToken) GetExpiration() int64 {
  return p.Expiration
}

func (p *ChannelToken) GetRefreshToken() string {
  return p.RefreshToken
}

func (p *ChannelToken) GetChannelAccessToken() string {
  return p.ChannelAccessToken
}
func (p *ChannelToken) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 5:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField5(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelToken)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.Token = v
}
  return nil
}

func (p *ChannelToken)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ObsToken = v
}
  return nil
}

func (p *ChannelToken)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Expiration = v
}
  return nil
}

func (p *ChannelToken)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.RefreshToken = v
}
  return nil
}

func (p *ChannelToken)  ReadField5(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 5: ", err)
} else {
  p.ChannelAccessToken = v
}
  return nil
}

func (p *ChannelToken) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("ChannelToken"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
    if err := p.writeField5(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelToken) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("token", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:token: ", p), err) }
  if err := oprot.WriteString(string(p.Token)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.token (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:token: ", p), err) }
  return err
}

func (p *ChannelToken) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("obsToken", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:obsToken: ", p), err) }
  if err := oprot.WriteString(string(p.ObsToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.obsToken (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:obsToken: ", p), err) }
  return err
}

func (p *ChannelToken) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("expiration", thrift.I64, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:expiration: ", p), err) }
  if err := oprot.WriteI64(int64(p.Expiration)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.expiration (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:expiration: ", p), err) }
  return err
}

func (p *ChannelToken) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("refreshToken", thrift.STRING, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:refreshToken: ", p), err) }
  if err := oprot.WriteString(string(p.RefreshToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.refreshToken (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:refreshToken: ", p), err) }
  return err
}

func (p *ChannelToken) writeField5(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelAccessToken", thrift.STRING, 5); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 5:channelAccessToken: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelAccessToken)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelAccessToken (5) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 5:channelAccessToken: ", p), err) }
  return err
}

func (p *ChannelToken) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelToken(%+v)", *p)
}

type ChannelService interface {
  // Parameters:
  //  - LastSynced
  GetDomains(ctx context.Context, lastSynced int64) (r *ChannelDomains, err error)
  // Parameters:
  //  - ChannelId
  //  - OtpId
  ApproveChannelAndIssueRequestToken(ctx context.Context, channelId string, otpId string) (r string, err error)
  // Parameters:
  //  - ChannelId
  IssueOTP(ctx context.Context, channelId string) (r *OTPResult_, err error)
  GetChannelSettings(ctx context.Context) (r *ChannelSettings, err error)
  // Parameters:
  //  - Locale
  GetChannelNotificationSettings(ctx context.Context, locale string) (r []*ChannelNotificationSetting, err error)
  // Parameters:
  //  - Setting
  UpdateChannelNotificationSetting(ctx context.Context, setting []*ChannelNotificationSetting) (err error)
  // Parameters:
  //  - ChannelSettings
  UpdateChannelSettings(ctx context.Context, channelSettings *ChannelSettings) (r bool, err error)
  // Parameters:
  //  - LastSynced
  GetCommonDomains(ctx context.Context, lastSynced int64) (r *ChannelDomains, err error)
  // Parameters:
  //  - ChannelId
  //  - OtpId
  //  - AuthScheme
  //  - ReturnUrl
  IssueRequestTokenWithAuthScheme(ctx context.Context, channelId string, otpId string, authScheme []string, returnUrl string) (r *RequestTokenResponse, err error)
  // Parameters:
  //  - ChannelId
  //  - Locale
  GetChannelNotificationSetting(ctx context.Context, channelId string, locale string) (r *ChannelNotificationSetting, err error)
  // Parameters:
  //  - ChannelId
  IssueChannelToken(ctx context.Context, channelId string) (r *ChannelToken, err error)
  // Parameters:
  //  - LastSynced
  //  - Locale
  GetChannels(ctx context.Context, lastSynced int64, locale string) (r *ChannelInfos, err error)
  // Parameters:
  //  - LocalRev
  FetchNotificationItems(ctx context.Context, localRev int64) (r *NotificationFetchResult_, err error)
  // Parameters:
  //  - ChannelId
  //  - Locale
  GetChannelInfo(ctx context.Context, channelId string, locale string) (r *ChannelInfo, err error)
  // Parameters:
  //  - LocalRev
  GetNotificationBadgeCount(ctx context.Context, localRev int64) (r int32, err error)
  // Parameters:
  //  - ChannelId
  //  - OtpId
  IssueRequestToken(ctx context.Context, channelId string, otpId string) (r string, err error)
  // Parameters:
  //  - ChannelId
  RevokeChannel(ctx context.Context, channelId string) (err error)
  // Parameters:
  //  - LastSynced
  //  - Locale
  GetApprovedChannels(ctx context.Context, lastSynced int64, locale string) (r *ApprovedChannelInfos, err error)
  // Parameters:
  //  - ChannelIds
  GetFriendChannelMatrices(ctx context.Context, channelIds []string) (r *FriendChannelMatricesResponse, err error)
  // Parameters:
  //  - ChannelId
  //  - OtpId
  //  - RedirectUrl
  IssueRequestTokenForAutoLogin(ctx context.Context, channelId string, otpId string, redirectUrl string) (r string, err error)
  // Parameters:
  //  - ChannelIds
  GetUpdatedChannelIds(ctx context.Context, channelIds []*ChannelIdWithLastUpdated) (r []string, err error)
  // Parameters:
  //  - Request
  //  - Locale
  ReserveCoinUse(ctx context.Context, request *CoinUseReservation, locale string) (r string, err error)
  // Parameters:
  //  - LastSynced
  //  - Locale
  SyncChannelData(ctx context.Context, lastSynced int64, locale string) (r *ChannelSyncDatas, err error)
  // Parameters:
  //  - ChannelId
  ApproveChannelAndIssueChannelToken(ctx context.Context, channelId string) (r *ChannelToken, err error)
}

type ChannelServiceClient struct {
  c thrift.TClient
}

// Deprecated: Use NewChannelService instead
func NewChannelServiceClientFactory(t thrift.TTransport, f thrift.TProtocolFactory) *ChannelServiceClient {
  return &ChannelServiceClient{
    c: thrift.NewTStandardClient(f.GetProtocol(t), f.GetProtocol(t)),
  }
}

// Deprecated: Use NewChannelService instead
func NewChannelServiceClientProtocol(t thrift.TTransport, iprot thrift.TProtocol, oprot thrift.TProtocol) *ChannelServiceClient {
  return &ChannelServiceClient{
    c: thrift.NewTStandardClient(iprot, oprot),
  }
}

func NewChannelServiceClient(c thrift.TClient) *ChannelServiceClient {
  return &ChannelServiceClient{
    c: c,
  }
}

// Parameters:
//  - LastSynced
func (p *ChannelServiceClient) GetDomains(ctx context.Context, lastSynced int64) (r *ChannelDomains, err error) {
  var _args864 ChannelServiceGetDomainsArgs
  _args864.LastSynced = lastSynced
  var _result865 ChannelServiceGetDomainsResult
  if err = p.c.Call(ctx, "getDomains", &_args864, &_result865); err != nil {
    return
  }
  switch {
  case _result865.E!= nil:
    return r, _result865.E
  }

  return _result865.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
//  - OtpId
func (p *ChannelServiceClient) ApproveChannelAndIssueRequestToken(ctx context.Context, channelId string, otpId string) (r string, err error) {
  var _args866 ChannelServiceApproveChannelAndIssueRequestTokenArgs
  _args866.ChannelId = channelId
  _args866.OtpId = otpId
  var _result867 ChannelServiceApproveChannelAndIssueRequestTokenResult
  if err = p.c.Call(ctx, "approveChannelAndIssueRequestToken", &_args866, &_result867); err != nil {
    return
  }
  switch {
  case _result867.E!= nil:
    return r, _result867.E
  }

  return _result867.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
func (p *ChannelServiceClient) IssueOTP(ctx context.Context, channelId string) (r *OTPResult_, err error) {
  var _args868 ChannelServiceIssueOTPArgs
  _args868.ChannelId = channelId
  var _result869 ChannelServiceIssueOTPResult
  if err = p.c.Call(ctx, "issueOTP", &_args868, &_result869); err != nil {
    return
  }
  switch {
  case _result869.E!= nil:
    return r, _result869.E
  }

  return _result869.GetSuccess(), nil
}

func (p *ChannelServiceClient) GetChannelSettings(ctx context.Context) (r *ChannelSettings, err error) {
  var _args870 ChannelServiceGetChannelSettingsArgs
  var _result871 ChannelServiceGetChannelSettingsResult
  if err = p.c.Call(ctx, "getChannelSettings", &_args870, &_result871); err != nil {
    return
  }
  switch {
  case _result871.E!= nil:
    return r, _result871.E
  }

  return _result871.GetSuccess(), nil
}

// Parameters:
//  - Locale
func (p *ChannelServiceClient) GetChannelNotificationSettings(ctx context.Context, locale string) (r []*ChannelNotificationSetting, err error) {
  var _args872 ChannelServiceGetChannelNotificationSettingsArgs
  _args872.Locale = locale
  var _result873 ChannelServiceGetChannelNotificationSettingsResult
  if err = p.c.Call(ctx, "getChannelNotificationSettings", &_args872, &_result873); err != nil {
    return
  }
  switch {
  case _result873.E!= nil:
    return r, _result873.E
  }

  return _result873.GetSuccess(), nil
}

// Parameters:
//  - Setting
func (p *ChannelServiceClient) UpdateChannelNotificationSetting(ctx context.Context, setting []*ChannelNotificationSetting) (err error) {
  var _args874 ChannelServiceUpdateChannelNotificationSettingArgs
  _args874.Setting = setting
  var _result875 ChannelServiceUpdateChannelNotificationSettingResult
  if err = p.c.Call(ctx, "updateChannelNotificationSetting", &_args874, &_result875); err != nil {
    return
  }
  switch {
  case _result875.E!= nil:
    return _result875.E
  }

  return nil
}

// Parameters:
//  - ChannelSettings
func (p *ChannelServiceClient) UpdateChannelSettings(ctx context.Context, channelSettings *ChannelSettings) (r bool, err error) {
  var _args876 ChannelServiceUpdateChannelSettingsArgs
  _args876.ChannelSettings = channelSettings
  var _result877 ChannelServiceUpdateChannelSettingsResult
  if err = p.c.Call(ctx, "updateChannelSettings", &_args876, &_result877); err != nil {
    return
  }
  switch {
  case _result877.E!= nil:
    return r, _result877.E
  }

  return _result877.GetSuccess(), nil
}

// Parameters:
//  - LastSynced
func (p *ChannelServiceClient) GetCommonDomains(ctx context.Context, lastSynced int64) (r *ChannelDomains, err error) {
  var _args878 ChannelServiceGetCommonDomainsArgs
  _args878.LastSynced = lastSynced
  var _result879 ChannelServiceGetCommonDomainsResult
  if err = p.c.Call(ctx, "getCommonDomains", &_args878, &_result879); err != nil {
    return
  }
  switch {
  case _result879.E!= nil:
    return r, _result879.E
  }

  return _result879.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
//  - OtpId
//  - AuthScheme
//  - ReturnUrl
func (p *ChannelServiceClient) IssueRequestTokenWithAuthScheme(ctx context.Context, channelId string, otpId string, authScheme []string, returnUrl string) (r *RequestTokenResponse, err error) {
  var _args880 ChannelServiceIssueRequestTokenWithAuthSchemeArgs
  _args880.ChannelId = channelId
  _args880.OtpId = otpId
  _args880.AuthScheme = authScheme
  _args880.ReturnUrl = returnUrl
  var _result881 ChannelServiceIssueRequestTokenWithAuthSchemeResult
  if err = p.c.Call(ctx, "issueRequestTokenWithAuthScheme", &_args880, &_result881); err != nil {
    return
  }
  switch {
  case _result881.E!= nil:
    return r, _result881.E
  }

  return _result881.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
//  - Locale
func (p *ChannelServiceClient) GetChannelNotificationSetting(ctx context.Context, channelId string, locale string) (r *ChannelNotificationSetting, err error) {
  var _args882 ChannelServiceGetChannelNotificationSettingArgs
  _args882.ChannelId = channelId
  _args882.Locale = locale
  var _result883 ChannelServiceGetChannelNotificationSettingResult
  if err = p.c.Call(ctx, "getChannelNotificationSetting", &_args882, &_result883); err != nil {
    return
  }
  switch {
  case _result883.E!= nil:
    return r, _result883.E
  }

  return _result883.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
func (p *ChannelServiceClient) IssueChannelToken(ctx context.Context, channelId string) (r *ChannelToken, err error) {
  var _args884 ChannelServiceIssueChannelTokenArgs
  _args884.ChannelId = channelId
  var _result885 ChannelServiceIssueChannelTokenResult
  if err = p.c.Call(ctx, "issueChannelToken", &_args884, &_result885); err != nil {
    return
  }
  switch {
  case _result885.E!= nil:
    return r, _result885.E
  }

  return _result885.GetSuccess(), nil
}

// Parameters:
//  - LastSynced
//  - Locale
func (p *ChannelServiceClient) GetChannels(ctx context.Context, lastSynced int64, locale string) (r *ChannelInfos, err error) {
  var _args886 ChannelServiceGetChannelsArgs
  _args886.LastSynced = lastSynced
  _args886.Locale = locale
  var _result887 ChannelServiceGetChannelsResult
  if err = p.c.Call(ctx, "getChannels", &_args886, &_result887); err != nil {
    return
  }
  switch {
  case _result887.E!= nil:
    return r, _result887.E
  }

  return _result887.GetSuccess(), nil
}

// Parameters:
//  - LocalRev
func (p *ChannelServiceClient) FetchNotificationItems(ctx context.Context, localRev int64) (r *NotificationFetchResult_, err error) {
  var _args888 ChannelServiceFetchNotificationItemsArgs
  _args888.LocalRev = localRev
  var _result889 ChannelServiceFetchNotificationItemsResult
  if err = p.c.Call(ctx, "fetchNotificationItems", &_args888, &_result889); err != nil {
    return
  }
  switch {
  case _result889.E!= nil:
    return r, _result889.E
  }

  return _result889.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
//  - Locale
func (p *ChannelServiceClient) GetChannelInfo(ctx context.Context, channelId string, locale string) (r *ChannelInfo, err error) {
  var _args890 ChannelServiceGetChannelInfoArgs
  _args890.ChannelId = channelId
  _args890.Locale = locale
  var _result891 ChannelServiceGetChannelInfoResult
  if err = p.c.Call(ctx, "getChannelInfo", &_args890, &_result891); err != nil {
    return
  }
  switch {
  case _result891.E!= nil:
    return r, _result891.E
  }

  return _result891.GetSuccess(), nil
}

// Parameters:
//  - LocalRev
func (p *ChannelServiceClient) GetNotificationBadgeCount(ctx context.Context, localRev int64) (r int32, err error) {
  var _args892 ChannelServiceGetNotificationBadgeCountArgs
  _args892.LocalRev = localRev
  var _result893 ChannelServiceGetNotificationBadgeCountResult
  if err = p.c.Call(ctx, "getNotificationBadgeCount", &_args892, &_result893); err != nil {
    return
  }
  switch {
  case _result893.E!= nil:
    return r, _result893.E
  }

  return _result893.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
//  - OtpId
func (p *ChannelServiceClient) IssueRequestToken(ctx context.Context, channelId string, otpId string) (r string, err error) {
  var _args894 ChannelServiceIssueRequestTokenArgs
  _args894.ChannelId = channelId
  _args894.OtpId = otpId
  var _result895 ChannelServiceIssueRequestTokenResult
  if err = p.c.Call(ctx, "issueRequestToken", &_args894, &_result895); err != nil {
    return
  }
  switch {
  case _result895.E!= nil:
    return r, _result895.E
  }

  return _result895.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
func (p *ChannelServiceClient) RevokeChannel(ctx context.Context, channelId string) (err error) {
  var _args896 ChannelServiceRevokeChannelArgs
  _args896.ChannelId = channelId
  var _result897 ChannelServiceRevokeChannelResult
  if err = p.c.Call(ctx, "revokeChannel", &_args896, &_result897); err != nil {
    return
  }
  switch {
  case _result897.E!= nil:
    return _result897.E
  }

  return nil
}

// Parameters:
//  - LastSynced
//  - Locale
func (p *ChannelServiceClient) GetApprovedChannels(ctx context.Context, lastSynced int64, locale string) (r *ApprovedChannelInfos, err error) {
  var _args898 ChannelServiceGetApprovedChannelsArgs
  _args898.LastSynced = lastSynced
  _args898.Locale = locale
  var _result899 ChannelServiceGetApprovedChannelsResult
  if err = p.c.Call(ctx, "getApprovedChannels", &_args898, &_result899); err != nil {
    return
  }
  switch {
  case _result899.E!= nil:
    return r, _result899.E
  }

  return _result899.GetSuccess(), nil
}

// Parameters:
//  - ChannelIds
func (p *ChannelServiceClient) GetFriendChannelMatrices(ctx context.Context, channelIds []string) (r *FriendChannelMatricesResponse, err error) {
  var _args900 ChannelServiceGetFriendChannelMatricesArgs
  _args900.ChannelIds = channelIds
  var _result901 ChannelServiceGetFriendChannelMatricesResult
  if err = p.c.Call(ctx, "getFriendChannelMatrices", &_args900, &_result901); err != nil {
    return
  }
  switch {
  case _result901.E!= nil:
    return r, _result901.E
  }

  return _result901.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
//  - OtpId
//  - RedirectUrl
func (p *ChannelServiceClient) IssueRequestTokenForAutoLogin(ctx context.Context, channelId string, otpId string, redirectUrl string) (r string, err error) {
  var _args902 ChannelServiceIssueRequestTokenForAutoLoginArgs
  _args902.ChannelId = channelId
  _args902.OtpId = otpId
  _args902.RedirectUrl = redirectUrl
  var _result903 ChannelServiceIssueRequestTokenForAutoLoginResult
  if err = p.c.Call(ctx, "issueRequestTokenForAutoLogin", &_args902, &_result903); err != nil {
    return
  }
  switch {
  case _result903.E!= nil:
    return r, _result903.E
  }

  return _result903.GetSuccess(), nil
}

// Parameters:
//  - ChannelIds
func (p *ChannelServiceClient) GetUpdatedChannelIds(ctx context.Context, channelIds []*ChannelIdWithLastUpdated) (r []string, err error) {
  var _args904 ChannelServiceGetUpdatedChannelIdsArgs
  _args904.ChannelIds = channelIds
  var _result905 ChannelServiceGetUpdatedChannelIdsResult
  if err = p.c.Call(ctx, "getUpdatedChannelIds", &_args904, &_result905); err != nil {
    return
  }
  switch {
  case _result905.E!= nil:
    return r, _result905.E
  }

  return _result905.GetSuccess(), nil
}

// Parameters:
//  - Request
//  - Locale
func (p *ChannelServiceClient) ReserveCoinUse(ctx context.Context, request *CoinUseReservation, locale string) (r string, err error) {
  var _args906 ChannelServiceReserveCoinUseArgs
  _args906.Request = request
  _args906.Locale = locale
  var _result907 ChannelServiceReserveCoinUseResult
  if err = p.c.Call(ctx, "reserveCoinUse", &_args906, &_result907); err != nil {
    return
  }
  switch {
  case _result907.E!= nil:
    return r, _result907.E
  }

  return _result907.GetSuccess(), nil
}

// Parameters:
//  - LastSynced
//  - Locale
func (p *ChannelServiceClient) SyncChannelData(ctx context.Context, lastSynced int64, locale string) (r *ChannelSyncDatas, err error) {
  var _args908 ChannelServiceSyncChannelDataArgs
  _args908.LastSynced = lastSynced
  _args908.Locale = locale
  var _result909 ChannelServiceSyncChannelDataResult
  if err = p.c.Call(ctx, "syncChannelData", &_args908, &_result909); err != nil {
    return
  }
  switch {
  case _result909.E!= nil:
    return r, _result909.E
  }

  return _result909.GetSuccess(), nil
}

// Parameters:
//  - ChannelId
func (p *ChannelServiceClient) ApproveChannelAndIssueChannelToken(ctx context.Context, channelId string) (r *ChannelToken, err error) {
  var _args910 ChannelServiceApproveChannelAndIssueChannelTokenArgs
  _args910.ChannelId = channelId
  var _result911 ChannelServiceApproveChannelAndIssueChannelTokenResult
  if err = p.c.Call(ctx, "approveChannelAndIssueChannelToken", &_args910, &_result911); err != nil {
    return
  }
  switch {
  case _result911.E!= nil:
    return r, _result911.E
  }

  return _result911.GetSuccess(), nil
}

type ChannelServiceProcessor struct {
  processorMap map[string]thrift.TProcessorFunction
  handler ChannelService
}

func (p *ChannelServiceProcessor) AddToProcessorMap(key string, processor thrift.TProcessorFunction) {
  p.processorMap[key] = processor
}

func (p *ChannelServiceProcessor) GetProcessorFunction(key string) (processor thrift.TProcessorFunction, ok bool) {
  processor, ok = p.processorMap[key]
  return processor, ok
}

func (p *ChannelServiceProcessor) ProcessorMap() map[string]thrift.TProcessorFunction {
  return p.processorMap
}

func NewChannelServiceProcessor(handler ChannelService) *ChannelServiceProcessor {

  self912 := &ChannelServiceProcessor{handler:handler, processorMap:make(map[string]thrift.TProcessorFunction)}
  self912.processorMap["getDomains"] = &channelServiceProcessorGetDomains{handler:handler}
  self912.processorMap["approveChannelAndIssueRequestToken"] = &channelServiceProcessorApproveChannelAndIssueRequestToken{handler:handler}
  self912.processorMap["issueOTP"] = &channelServiceProcessorIssueOTP{handler:handler}
  self912.processorMap["getChannelSettings"] = &channelServiceProcessorGetChannelSettings{handler:handler}
  self912.processorMap["getChannelNotificationSettings"] = &channelServiceProcessorGetChannelNotificationSettings{handler:handler}
  self912.processorMap["updateChannelNotificationSetting"] = &channelServiceProcessorUpdateChannelNotificationSetting{handler:handler}
  self912.processorMap["updateChannelSettings"] = &channelServiceProcessorUpdateChannelSettings{handler:handler}
  self912.processorMap["getCommonDomains"] = &channelServiceProcessorGetCommonDomains{handler:handler}
  self912.processorMap["issueRequestTokenWithAuthScheme"] = &channelServiceProcessorIssueRequestTokenWithAuthScheme{handler:handler}
  self912.processorMap["getChannelNotificationSetting"] = &channelServiceProcessorGetChannelNotificationSetting{handler:handler}
  self912.processorMap["issueChannelToken"] = &channelServiceProcessorIssueChannelToken{handler:handler}
  self912.processorMap["getChannels"] = &channelServiceProcessorGetChannels{handler:handler}
  self912.processorMap["fetchNotificationItems"] = &channelServiceProcessorFetchNotificationItems{handler:handler}
  self912.processorMap["getChannelInfo"] = &channelServiceProcessorGetChannelInfo{handler:handler}
  self912.processorMap["getNotificationBadgeCount"] = &channelServiceProcessorGetNotificationBadgeCount{handler:handler}
  self912.processorMap["issueRequestToken"] = &channelServiceProcessorIssueRequestToken{handler:handler}
  self912.processorMap["revokeChannel"] = &channelServiceProcessorRevokeChannel{handler:handler}
  self912.processorMap["getApprovedChannels"] = &channelServiceProcessorGetApprovedChannels{handler:handler}
  self912.processorMap["getFriendChannelMatrices"] = &channelServiceProcessorGetFriendChannelMatrices{handler:handler}
  self912.processorMap["issueRequestTokenForAutoLogin"] = &channelServiceProcessorIssueRequestTokenForAutoLogin{handler:handler}
  self912.processorMap["getUpdatedChannelIds"] = &channelServiceProcessorGetUpdatedChannelIds{handler:handler}
  self912.processorMap["reserveCoinUse"] = &channelServiceProcessorReserveCoinUse{handler:handler}
  self912.processorMap["syncChannelData"] = &channelServiceProcessorSyncChannelData{handler:handler}
  self912.processorMap["approveChannelAndIssueChannelToken"] = &channelServiceProcessorApproveChannelAndIssueChannelToken{handler:handler}
return self912
}

func (p *ChannelServiceProcessor) Process(ctx context.Context, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  name, _, seqId, err := iprot.ReadMessageBegin()
  if err != nil { return false, err }
  if processor, ok := p.GetProcessorFunction(name); ok {
    return processor.Process(ctx, seqId, iprot, oprot)
  }
  iprot.Skip(thrift.STRUCT)
  iprot.ReadMessageEnd()
  x913 := thrift.NewTApplicationException(thrift.UNKNOWN_METHOD, "Unknown function " + name)
  oprot.WriteMessageBegin(name, thrift.EXCEPTION, seqId)
  x913.Write(oprot)
  oprot.WriteMessageEnd()
  oprot.Flush(ctx)
  return false, x913

}

type channelServiceProcessorGetDomains struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetDomains) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetDomainsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getDomains", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetDomainsResult{}
var retval *ChannelDomains
  var err2 error
  if retval, err2 = p.handler.GetDomains(ctx, args.LastSynced); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getDomains: " + err2.Error())
    oprot.WriteMessageBegin("getDomains", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getDomains", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorApproveChannelAndIssueRequestToken struct {
  handler ChannelService
}

func (p *channelServiceProcessorApproveChannelAndIssueRequestToken) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceApproveChannelAndIssueRequestTokenArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("approveChannelAndIssueRequestToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceApproveChannelAndIssueRequestTokenResult{}
var retval string
  var err2 error
  if retval, err2 = p.handler.ApproveChannelAndIssueRequestToken(ctx, args.ChannelId, args.OtpId); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing approveChannelAndIssueRequestToken: " + err2.Error())
    oprot.WriteMessageBegin("approveChannelAndIssueRequestToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = &retval
}
  if err2 = oprot.WriteMessageBegin("approveChannelAndIssueRequestToken", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorIssueOTP struct {
  handler ChannelService
}

func (p *channelServiceProcessorIssueOTP) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceIssueOTPArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("issueOTP", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceIssueOTPResult{}
var retval *OTPResult_
  var err2 error
  if retval, err2 = p.handler.IssueOTP(ctx, args.ChannelId); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing issueOTP: " + err2.Error())
    oprot.WriteMessageBegin("issueOTP", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("issueOTP", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetChannelSettings struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetChannelSettings) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetChannelSettingsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getChannelSettings", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetChannelSettingsResult{}
var retval *ChannelSettings
  var err2 error
  if retval, err2 = p.handler.GetChannelSettings(ctx); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getChannelSettings: " + err2.Error())
    oprot.WriteMessageBegin("getChannelSettings", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getChannelSettings", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetChannelNotificationSettings struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetChannelNotificationSettings) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetChannelNotificationSettingsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getChannelNotificationSettings", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetChannelNotificationSettingsResult{}
var retval []*ChannelNotificationSetting
  var err2 error
  if retval, err2 = p.handler.GetChannelNotificationSettings(ctx, args.Locale); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getChannelNotificationSettings: " + err2.Error())
    oprot.WriteMessageBegin("getChannelNotificationSettings", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getChannelNotificationSettings", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorUpdateChannelNotificationSetting struct {
  handler ChannelService
}

func (p *channelServiceProcessorUpdateChannelNotificationSetting) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceUpdateChannelNotificationSettingArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("updateChannelNotificationSetting", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceUpdateChannelNotificationSettingResult{}
  var err2 error
  if err2 = p.handler.UpdateChannelNotificationSetting(ctx, args.Setting); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing updateChannelNotificationSetting: " + err2.Error())
    oprot.WriteMessageBegin("updateChannelNotificationSetting", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  }
  if err2 = oprot.WriteMessageBegin("updateChannelNotificationSetting", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorUpdateChannelSettings struct {
  handler ChannelService
}

func (p *channelServiceProcessorUpdateChannelSettings) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceUpdateChannelSettingsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("updateChannelSettings", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceUpdateChannelSettingsResult{}
var retval bool
  var err2 error
  if retval, err2 = p.handler.UpdateChannelSettings(ctx, args.ChannelSettings); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing updateChannelSettings: " + err2.Error())
    oprot.WriteMessageBegin("updateChannelSettings", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = &retval
}
  if err2 = oprot.WriteMessageBegin("updateChannelSettings", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetCommonDomains struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetCommonDomains) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetCommonDomainsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getCommonDomains", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetCommonDomainsResult{}
var retval *ChannelDomains
  var err2 error
  if retval, err2 = p.handler.GetCommonDomains(ctx, args.LastSynced); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getCommonDomains: " + err2.Error())
    oprot.WriteMessageBegin("getCommonDomains", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getCommonDomains", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorIssueRequestTokenWithAuthScheme struct {
  handler ChannelService
}

func (p *channelServiceProcessorIssueRequestTokenWithAuthScheme) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceIssueRequestTokenWithAuthSchemeArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("issueRequestTokenWithAuthScheme", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceIssueRequestTokenWithAuthSchemeResult{}
var retval *RequestTokenResponse
  var err2 error
  if retval, err2 = p.handler.IssueRequestTokenWithAuthScheme(ctx, args.ChannelId, args.OtpId, args.AuthScheme, args.ReturnUrl); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing issueRequestTokenWithAuthScheme: " + err2.Error())
    oprot.WriteMessageBegin("issueRequestTokenWithAuthScheme", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("issueRequestTokenWithAuthScheme", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetChannelNotificationSetting struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetChannelNotificationSetting) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetChannelNotificationSettingArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getChannelNotificationSetting", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetChannelNotificationSettingResult{}
var retval *ChannelNotificationSetting
  var err2 error
  if retval, err2 = p.handler.GetChannelNotificationSetting(ctx, args.ChannelId, args.Locale); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getChannelNotificationSetting: " + err2.Error())
    oprot.WriteMessageBegin("getChannelNotificationSetting", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getChannelNotificationSetting", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorIssueChannelToken struct {
  handler ChannelService
}

func (p *channelServiceProcessorIssueChannelToken) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceIssueChannelTokenArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("issueChannelToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceIssueChannelTokenResult{}
var retval *ChannelToken
  var err2 error
  if retval, err2 = p.handler.IssueChannelToken(ctx, args.ChannelId); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing issueChannelToken: " + err2.Error())
    oprot.WriteMessageBegin("issueChannelToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("issueChannelToken", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetChannels struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetChannels) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetChannelsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getChannels", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetChannelsResult{}
var retval *ChannelInfos
  var err2 error
  if retval, err2 = p.handler.GetChannels(ctx, args.LastSynced, args.Locale); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getChannels: " + err2.Error())
    oprot.WriteMessageBegin("getChannels", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getChannels", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorFetchNotificationItems struct {
  handler ChannelService
}

func (p *channelServiceProcessorFetchNotificationItems) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceFetchNotificationItemsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("fetchNotificationItems", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceFetchNotificationItemsResult{}
var retval *NotificationFetchResult_
  var err2 error
  if retval, err2 = p.handler.FetchNotificationItems(ctx, args.LocalRev); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing fetchNotificationItems: " + err2.Error())
    oprot.WriteMessageBegin("fetchNotificationItems", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("fetchNotificationItems", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetChannelInfo struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetChannelInfo) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetChannelInfoArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getChannelInfo", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetChannelInfoResult{}
var retval *ChannelInfo
  var err2 error
  if retval, err2 = p.handler.GetChannelInfo(ctx, args.ChannelId, args.Locale); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getChannelInfo: " + err2.Error())
    oprot.WriteMessageBegin("getChannelInfo", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getChannelInfo", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetNotificationBadgeCount struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetNotificationBadgeCount) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetNotificationBadgeCountArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getNotificationBadgeCount", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetNotificationBadgeCountResult{}
var retval int32
  var err2 error
  if retval, err2 = p.handler.GetNotificationBadgeCount(ctx, args.LocalRev); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getNotificationBadgeCount: " + err2.Error())
    oprot.WriteMessageBegin("getNotificationBadgeCount", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = &retval
}
  if err2 = oprot.WriteMessageBegin("getNotificationBadgeCount", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorIssueRequestToken struct {
  handler ChannelService
}

func (p *channelServiceProcessorIssueRequestToken) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceIssueRequestTokenArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("issueRequestToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceIssueRequestTokenResult{}
var retval string
  var err2 error
  if retval, err2 = p.handler.IssueRequestToken(ctx, args.ChannelId, args.OtpId); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing issueRequestToken: " + err2.Error())
    oprot.WriteMessageBegin("issueRequestToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = &retval
}
  if err2 = oprot.WriteMessageBegin("issueRequestToken", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorRevokeChannel struct {
  handler ChannelService
}

func (p *channelServiceProcessorRevokeChannel) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceRevokeChannelArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("revokeChannel", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceRevokeChannelResult{}
  var err2 error
  if err2 = p.handler.RevokeChannel(ctx, args.ChannelId); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing revokeChannel: " + err2.Error())
    oprot.WriteMessageBegin("revokeChannel", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  }
  if err2 = oprot.WriteMessageBegin("revokeChannel", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetApprovedChannels struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetApprovedChannels) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetApprovedChannelsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getApprovedChannels", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetApprovedChannelsResult{}
var retval *ApprovedChannelInfos
  var err2 error
  if retval, err2 = p.handler.GetApprovedChannels(ctx, args.LastSynced, args.Locale); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getApprovedChannels: " + err2.Error())
    oprot.WriteMessageBegin("getApprovedChannels", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getApprovedChannels", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetFriendChannelMatrices struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetFriendChannelMatrices) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetFriendChannelMatricesArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getFriendChannelMatrices", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetFriendChannelMatricesResult{}
var retval *FriendChannelMatricesResponse
  var err2 error
  if retval, err2 = p.handler.GetFriendChannelMatrices(ctx, args.ChannelIds); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getFriendChannelMatrices: " + err2.Error())
    oprot.WriteMessageBegin("getFriendChannelMatrices", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getFriendChannelMatrices", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorIssueRequestTokenForAutoLogin struct {
  handler ChannelService
}

func (p *channelServiceProcessorIssueRequestTokenForAutoLogin) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceIssueRequestTokenForAutoLoginArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("issueRequestTokenForAutoLogin", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceIssueRequestTokenForAutoLoginResult{}
var retval string
  var err2 error
  if retval, err2 = p.handler.IssueRequestTokenForAutoLogin(ctx, args.ChannelId, args.OtpId, args.RedirectUrl); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing issueRequestTokenForAutoLogin: " + err2.Error())
    oprot.WriteMessageBegin("issueRequestTokenForAutoLogin", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = &retval
}
  if err2 = oprot.WriteMessageBegin("issueRequestTokenForAutoLogin", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorGetUpdatedChannelIds struct {
  handler ChannelService
}

func (p *channelServiceProcessorGetUpdatedChannelIds) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceGetUpdatedChannelIdsArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("getUpdatedChannelIds", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceGetUpdatedChannelIdsResult{}
var retval []string
  var err2 error
  if retval, err2 = p.handler.GetUpdatedChannelIds(ctx, args.ChannelIds); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing getUpdatedChannelIds: " + err2.Error())
    oprot.WriteMessageBegin("getUpdatedChannelIds", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("getUpdatedChannelIds", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorReserveCoinUse struct {
  handler ChannelService
}

func (p *channelServiceProcessorReserveCoinUse) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceReserveCoinUseArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("reserveCoinUse", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceReserveCoinUseResult{}
var retval string
  var err2 error
  if retval, err2 = p.handler.ReserveCoinUse(ctx, args.Request, args.Locale); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing reserveCoinUse: " + err2.Error())
    oprot.WriteMessageBegin("reserveCoinUse", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = &retval
}
  if err2 = oprot.WriteMessageBegin("reserveCoinUse", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorSyncChannelData struct {
  handler ChannelService
}

func (p *channelServiceProcessorSyncChannelData) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceSyncChannelDataArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("syncChannelData", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceSyncChannelDataResult{}
var retval *ChannelSyncDatas
  var err2 error
  if retval, err2 = p.handler.SyncChannelData(ctx, args.LastSynced, args.Locale); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing syncChannelData: " + err2.Error())
    oprot.WriteMessageBegin("syncChannelData", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("syncChannelData", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}

type channelServiceProcessorApproveChannelAndIssueChannelToken struct {
  handler ChannelService
}

func (p *channelServiceProcessorApproveChannelAndIssueChannelToken) Process(ctx context.Context, seqId int32, iprot, oprot thrift.TProtocol) (success bool, err thrift.TException) {
  args := ChannelServiceApproveChannelAndIssueChannelTokenArgs{}
  if err = args.Read(iprot); err != nil {
    iprot.ReadMessageEnd()
    x := thrift.NewTApplicationException(thrift.PROTOCOL_ERROR, err.Error())
    oprot.WriteMessageBegin("approveChannelAndIssueChannelToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return false, err
  }

  iprot.ReadMessageEnd()
  result := ChannelServiceApproveChannelAndIssueChannelTokenResult{}
var retval *ChannelToken
  var err2 error
  if retval, err2 = p.handler.ApproveChannelAndIssueChannelToken(ctx, args.ChannelId); err2 != nil {
  switch v := err2.(type) {
    case *ChannelException:
  result.E = v
    default:
    x := thrift.NewTApplicationException(thrift.INTERNAL_ERROR, "Internal error processing approveChannelAndIssueChannelToken: " + err2.Error())
    oprot.WriteMessageBegin("approveChannelAndIssueChannelToken", thrift.EXCEPTION, seqId)
    x.Write(oprot)
    oprot.WriteMessageEnd()
    oprot.Flush(ctx)
    return true, err2
  }
  } else {
    result.Success = retval
}
  if err2 = oprot.WriteMessageBegin("approveChannelAndIssueChannelToken", thrift.REPLY, seqId); err2 != nil {
    err = err2
  }
  if err2 = result.Write(oprot); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.WriteMessageEnd(); err == nil && err2 != nil {
    err = err2
  }
  if err2 = oprot.Flush(ctx); err == nil && err2 != nil {
    err = err2
  }
  if err != nil {
    return
  }
  return true, err
}


// HELPER FUNCTIONS AND STRUCTURES

// Attributes:
//  - LastSynced
type ChannelServiceGetDomainsArgs struct {
  // unused field # 1
  LastSynced int64 `thrift:"lastSynced,2" db:"lastSynced" json:"lastSynced"`
}

func NewChannelServiceGetDomainsArgs() *ChannelServiceGetDomainsArgs {
  return &ChannelServiceGetDomainsArgs{}
}


func (p *ChannelServiceGetDomainsArgs) GetLastSynced() int64 {
  return p.LastSynced
}
func (p *ChannelServiceGetDomainsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetDomainsArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.LastSynced = v
}
  return nil
}

func (p *ChannelServiceGetDomainsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getDomains_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetDomainsArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("lastSynced", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:lastSynced: ", p), err) }
  if err := oprot.WriteI64(int64(p.LastSynced)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.lastSynced (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:lastSynced: ", p), err) }
  return err
}

func (p *ChannelServiceGetDomainsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetDomainsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetDomainsResult struct {
  Success *ChannelDomains `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetDomainsResult() *ChannelServiceGetDomainsResult {
  return &ChannelServiceGetDomainsResult{}
}

var ChannelServiceGetDomainsResult_Success_DEFAULT *ChannelDomains
func (p *ChannelServiceGetDomainsResult) GetSuccess() *ChannelDomains {
  if !p.IsSetSuccess() {
    return ChannelServiceGetDomainsResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetDomainsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetDomainsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetDomainsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetDomainsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetDomainsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetDomainsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetDomainsResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelDomains{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetDomainsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetDomainsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getDomains_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetDomainsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetDomainsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetDomainsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetDomainsResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - OtpId
type ChannelServiceApproveChannelAndIssueRequestTokenArgs struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  OtpId string `thrift:"otpId,2" db:"otpId" json:"otpId"`
}

func NewChannelServiceApproveChannelAndIssueRequestTokenArgs() *ChannelServiceApproveChannelAndIssueRequestTokenArgs {
  return &ChannelServiceApproveChannelAndIssueRequestTokenArgs{}
}


func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs) GetOtpId() string {
  return p.OtpId
}
func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.OtpId = v
}
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("approveChannelAndIssueRequestToken_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("otpId", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:otpId: ", p), err) }
  if err := oprot.WriteString(string(p.OtpId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.otpId (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:otpId: ", p), err) }
  return err
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceApproveChannelAndIssueRequestTokenArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceApproveChannelAndIssueRequestTokenResult struct {
  Success *string `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceApproveChannelAndIssueRequestTokenResult() *ChannelServiceApproveChannelAndIssueRequestTokenResult {
  return &ChannelServiceApproveChannelAndIssueRequestTokenResult{}
}

var ChannelServiceApproveChannelAndIssueRequestTokenResult_Success_DEFAULT string
func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) GetSuccess() string {
  if !p.IsSetSuccess() {
    return ChannelServiceApproveChannelAndIssueRequestTokenResult_Success_DEFAULT
  }
return *p.Success
}
var ChannelServiceApproveChannelAndIssueRequestTokenResult_E_DEFAULT *ChannelException
func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceApproveChannelAndIssueRequestTokenResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult)  ReadField0(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 0: ", err)
} else {
  p.Success = &v
}
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("approveChannelAndIssueRequestToken_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRING, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteString(string(*p.Success)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T.success (0) field write error: ", p), err) }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceApproveChannelAndIssueRequestTokenResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceApproveChannelAndIssueRequestTokenResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
type ChannelServiceIssueOTPArgs struct {
  // unused field # 1
  ChannelId string `thrift:"channelId,2" db:"channelId" json:"channelId"`
}

func NewChannelServiceIssueOTPArgs() *ChannelServiceIssueOTPArgs {
  return &ChannelServiceIssueOTPArgs{}
}


func (p *ChannelServiceIssueOTPArgs) GetChannelId() string {
  return p.ChannelId
}
func (p *ChannelServiceIssueOTPArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueOTPArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceIssueOTPArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueOTP_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueOTPArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueOTPArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueOTPArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceIssueOTPResult struct {
  Success *OTPResult_ `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceIssueOTPResult() *ChannelServiceIssueOTPResult {
  return &ChannelServiceIssueOTPResult{}
}

var ChannelServiceIssueOTPResult_Success_DEFAULT *OTPResult_
func (p *ChannelServiceIssueOTPResult) GetSuccess() *OTPResult_ {
  if !p.IsSetSuccess() {
    return ChannelServiceIssueOTPResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceIssueOTPResult_E_DEFAULT *ChannelException
func (p *ChannelServiceIssueOTPResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceIssueOTPResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceIssueOTPResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceIssueOTPResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceIssueOTPResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueOTPResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &OTPResult_{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceIssueOTPResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceIssueOTPResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueOTP_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueOTPResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueOTPResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueOTPResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueOTPResult(%+v)", *p)
}

type ChannelServiceGetChannelSettingsArgs struct {
}

func NewChannelServiceGetChannelSettingsArgs() *ChannelServiceGetChannelSettingsArgs {
  return &ChannelServiceGetChannelSettingsArgs{}
}

func (p *ChannelServiceGetChannelSettingsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    if err := iprot.Skip(fieldTypeId); err != nil {
      return err
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelSettingsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelSettings_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelSettingsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelSettingsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetChannelSettingsResult struct {
  Success *ChannelSettings `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetChannelSettingsResult() *ChannelServiceGetChannelSettingsResult {
  return &ChannelServiceGetChannelSettingsResult{}
}

var ChannelServiceGetChannelSettingsResult_Success_DEFAULT *ChannelSettings
func (p *ChannelServiceGetChannelSettingsResult) GetSuccess() *ChannelSettings {
  if !p.IsSetSuccess() {
    return ChannelServiceGetChannelSettingsResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetChannelSettingsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetChannelSettingsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetChannelSettingsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetChannelSettingsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetChannelSettingsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetChannelSettingsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelSettingsResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelSettings{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelSettingsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelSettingsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelSettings_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelSettingsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelSettingsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelSettingsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelSettingsResult(%+v)", *p)
}

// Attributes:
//  - Locale
type ChannelServiceGetChannelNotificationSettingsArgs struct {
  Locale string `thrift:"locale,1" db:"locale" json:"locale"`
}

func NewChannelServiceGetChannelNotificationSettingsArgs() *ChannelServiceGetChannelNotificationSettingsArgs {
  return &ChannelServiceGetChannelNotificationSettingsArgs{}
}


func (p *ChannelServiceGetChannelNotificationSettingsArgs) GetLocale() string {
  return p.Locale
}
func (p *ChannelServiceGetChannelNotificationSettingsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingsArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.Locale = v
}
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelNotificationSettings_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingsArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("locale", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:locale: ", p), err) }
  if err := oprot.WriteString(string(p.Locale)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.locale (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:locale: ", p), err) }
  return err
}

func (p *ChannelServiceGetChannelNotificationSettingsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelNotificationSettingsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetChannelNotificationSettingsResult struct {
  Success []*ChannelNotificationSetting `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetChannelNotificationSettingsResult() *ChannelServiceGetChannelNotificationSettingsResult {
  return &ChannelServiceGetChannelNotificationSettingsResult{}
}

var ChannelServiceGetChannelNotificationSettingsResult_Success_DEFAULT []*ChannelNotificationSetting

func (p *ChannelServiceGetChannelNotificationSettingsResult) GetSuccess() []*ChannelNotificationSetting {
  return p.Success
}
var ChannelServiceGetChannelNotificationSettingsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetChannelNotificationSettingsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetChannelNotificationSettingsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetChannelNotificationSettingsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetChannelNotificationSettingsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetChannelNotificationSettingsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingsResult)  ReadField0(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelNotificationSetting, 0, size)
  p.Success =  tSlice
  for i := 0; i < size; i ++ {
    _elem914 := &ChannelNotificationSetting{}
    if err := _elem914.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem914), err)
    }
    p.Success = append(p.Success, _elem914)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelNotificationSettings_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.LIST, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteListBegin(thrift.STRUCT, len(p.Success)); err != nil {
      return thrift.PrependError("error writing list begin: ", err)
    }
    for _, v := range p.Success {
      if err := v.Write(oprot); err != nil {
        return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
      }
    }
    if err := oprot.WriteListEnd(); err != nil {
      return thrift.PrependError("error writing list end: ", err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelNotificationSettingsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelNotificationSettingsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelNotificationSettingsResult(%+v)", *p)
}

// Attributes:
//  - Setting
type ChannelServiceUpdateChannelNotificationSettingArgs struct {
  Setting []*ChannelNotificationSetting `thrift:"setting,1" db:"setting" json:"setting"`
}

func NewChannelServiceUpdateChannelNotificationSettingArgs() *ChannelServiceUpdateChannelNotificationSettingArgs {
  return &ChannelServiceUpdateChannelNotificationSettingArgs{}
}


func (p *ChannelServiceUpdateChannelNotificationSettingArgs) GetSetting() []*ChannelNotificationSetting {
  return p.Setting
}
func (p *ChannelServiceUpdateChannelNotificationSettingArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelNotificationSettingArgs)  ReadField1(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelNotificationSetting, 0, size)
  p.Setting =  tSlice
  for i := 0; i < size; i ++ {
    _elem915 := &ChannelNotificationSetting{}
    if err := _elem915.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem915), err)
    }
    p.Setting = append(p.Setting, _elem915)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelNotificationSettingArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("updateChannelNotificationSetting_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceUpdateChannelNotificationSettingArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("setting", thrift.LIST, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:setting: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.Setting)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.Setting {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:setting: ", p), err) }
  return err
}

func (p *ChannelServiceUpdateChannelNotificationSettingArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceUpdateChannelNotificationSettingArgs(%+v)", *p)
}

// Attributes:
//  - E
type ChannelServiceUpdateChannelNotificationSettingResult struct {
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceUpdateChannelNotificationSettingResult() *ChannelServiceUpdateChannelNotificationSettingResult {
  return &ChannelServiceUpdateChannelNotificationSettingResult{}
}

var ChannelServiceUpdateChannelNotificationSettingResult_E_DEFAULT *ChannelException
func (p *ChannelServiceUpdateChannelNotificationSettingResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceUpdateChannelNotificationSettingResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceUpdateChannelNotificationSettingResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceUpdateChannelNotificationSettingResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelNotificationSettingResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelNotificationSettingResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("updateChannelNotificationSetting_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceUpdateChannelNotificationSettingResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceUpdateChannelNotificationSettingResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceUpdateChannelNotificationSettingResult(%+v)", *p)
}

// Attributes:
//  - ChannelSettings
type ChannelServiceUpdateChannelSettingsArgs struct {
  ChannelSettings *ChannelSettings `thrift:"channelSettings,1" db:"channelSettings" json:"channelSettings"`
}

func NewChannelServiceUpdateChannelSettingsArgs() *ChannelServiceUpdateChannelSettingsArgs {
  return &ChannelServiceUpdateChannelSettingsArgs{}
}

var ChannelServiceUpdateChannelSettingsArgs_ChannelSettings_DEFAULT *ChannelSettings
func (p *ChannelServiceUpdateChannelSettingsArgs) GetChannelSettings() *ChannelSettings {
  if !p.IsSetChannelSettings() {
    return ChannelServiceUpdateChannelSettingsArgs_ChannelSettings_DEFAULT
  }
return p.ChannelSettings
}
func (p *ChannelServiceUpdateChannelSettingsArgs) IsSetChannelSettings() bool {
  return p.ChannelSettings != nil
}

func (p *ChannelServiceUpdateChannelSettingsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelSettingsArgs)  ReadField1(iprot thrift.TProtocol) error {
  p.ChannelSettings = &ChannelSettings{}
  if err := p.ChannelSettings.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.ChannelSettings), err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelSettingsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("updateChannelSettings_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceUpdateChannelSettingsArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelSettings", thrift.STRUCT, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelSettings: ", p), err) }
  if err := p.ChannelSettings.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.ChannelSettings), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelSettings: ", p), err) }
  return err
}

func (p *ChannelServiceUpdateChannelSettingsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceUpdateChannelSettingsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceUpdateChannelSettingsResult struct {
  Success *bool `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceUpdateChannelSettingsResult() *ChannelServiceUpdateChannelSettingsResult {
  return &ChannelServiceUpdateChannelSettingsResult{}
}

var ChannelServiceUpdateChannelSettingsResult_Success_DEFAULT bool
func (p *ChannelServiceUpdateChannelSettingsResult) GetSuccess() bool {
  if !p.IsSetSuccess() {
    return ChannelServiceUpdateChannelSettingsResult_Success_DEFAULT
  }
return *p.Success
}
var ChannelServiceUpdateChannelSettingsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceUpdateChannelSettingsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceUpdateChannelSettingsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceUpdateChannelSettingsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceUpdateChannelSettingsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceUpdateChannelSettingsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.BOOL {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelSettingsResult)  ReadField0(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadBool(); err != nil {
  return thrift.PrependError("error reading field 0: ", err)
} else {
  p.Success = &v
}
  return nil
}

func (p *ChannelServiceUpdateChannelSettingsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceUpdateChannelSettingsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("updateChannelSettings_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceUpdateChannelSettingsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.BOOL, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteBool(bool(*p.Success)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T.success (0) field write error: ", p), err) }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceUpdateChannelSettingsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceUpdateChannelSettingsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceUpdateChannelSettingsResult(%+v)", *p)
}

// Attributes:
//  - LastSynced
type ChannelServiceGetCommonDomainsArgs struct {
  LastSynced int64 `thrift:"lastSynced,1" db:"lastSynced" json:"lastSynced"`
}

func NewChannelServiceGetCommonDomainsArgs() *ChannelServiceGetCommonDomainsArgs {
  return &ChannelServiceGetCommonDomainsArgs{}
}


func (p *ChannelServiceGetCommonDomainsArgs) GetLastSynced() int64 {
  return p.LastSynced
}
func (p *ChannelServiceGetCommonDomainsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetCommonDomainsArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.LastSynced = v
}
  return nil
}

func (p *ChannelServiceGetCommonDomainsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getCommonDomains_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetCommonDomainsArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("lastSynced", thrift.I64, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:lastSynced: ", p), err) }
  if err := oprot.WriteI64(int64(p.LastSynced)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.lastSynced (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:lastSynced: ", p), err) }
  return err
}

func (p *ChannelServiceGetCommonDomainsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetCommonDomainsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetCommonDomainsResult struct {
  Success *ChannelDomains `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetCommonDomainsResult() *ChannelServiceGetCommonDomainsResult {
  return &ChannelServiceGetCommonDomainsResult{}
}

var ChannelServiceGetCommonDomainsResult_Success_DEFAULT *ChannelDomains
func (p *ChannelServiceGetCommonDomainsResult) GetSuccess() *ChannelDomains {
  if !p.IsSetSuccess() {
    return ChannelServiceGetCommonDomainsResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetCommonDomainsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetCommonDomainsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetCommonDomainsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetCommonDomainsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetCommonDomainsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetCommonDomainsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetCommonDomainsResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelDomains{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetCommonDomainsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetCommonDomainsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getCommonDomains_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetCommonDomainsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetCommonDomainsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetCommonDomainsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetCommonDomainsResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - OtpId
//  - AuthScheme
//  - ReturnUrl
type ChannelServiceIssueRequestTokenWithAuthSchemeArgs struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  OtpId string `thrift:"otpId,2" db:"otpId" json:"otpId"`
  AuthScheme []string `thrift:"authScheme,3" db:"authScheme" json:"authScheme"`
  ReturnUrl string `thrift:"returnUrl,4" db:"returnUrl" json:"returnUrl"`
}

func NewChannelServiceIssueRequestTokenWithAuthSchemeArgs() *ChannelServiceIssueRequestTokenWithAuthSchemeArgs {
  return &ChannelServiceIssueRequestTokenWithAuthSchemeArgs{}
}


func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) GetOtpId() string {
  return p.OtpId
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) GetAuthScheme() []string {
  return p.AuthScheme
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) GetReturnUrl() string {
  return p.ReturnUrl
}
func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.OtpId = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs)  ReadField3(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]string, 0, size)
  p.AuthScheme =  tSlice
  for i := 0; i < size; i ++ {
var _elem916 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _elem916 = v
}
    p.AuthScheme = append(p.AuthScheme, _elem916)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.ReturnUrl = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueRequestTokenWithAuthScheme_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("otpId", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:otpId: ", p), err) }
  if err := oprot.WriteString(string(p.OtpId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.otpId (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:otpId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("authScheme", thrift.LIST, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:authScheme: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRING, len(p.AuthScheme)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.AuthScheme {
    if err := oprot.WriteString(string(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:authScheme: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("returnUrl", thrift.STRING, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:returnUrl: ", p), err) }
  if err := oprot.WriteString(string(p.ReturnUrl)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.returnUrl (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:returnUrl: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueRequestTokenWithAuthSchemeArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceIssueRequestTokenWithAuthSchemeResult struct {
  Success *RequestTokenResponse `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceIssueRequestTokenWithAuthSchemeResult() *ChannelServiceIssueRequestTokenWithAuthSchemeResult {
  return &ChannelServiceIssueRequestTokenWithAuthSchemeResult{}
}

var ChannelServiceIssueRequestTokenWithAuthSchemeResult_Success_DEFAULT *RequestTokenResponse
func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) GetSuccess() *RequestTokenResponse {
  if !p.IsSetSuccess() {
    return ChannelServiceIssueRequestTokenWithAuthSchemeResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceIssueRequestTokenWithAuthSchemeResult_E_DEFAULT *ChannelException
func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceIssueRequestTokenWithAuthSchemeResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &RequestTokenResponse{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueRequestTokenWithAuthScheme_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueRequestTokenWithAuthSchemeResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueRequestTokenWithAuthSchemeResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - Locale
type ChannelServiceGetChannelNotificationSettingArgs struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  Locale string `thrift:"locale,2" db:"locale" json:"locale"`
}

func NewChannelServiceGetChannelNotificationSettingArgs() *ChannelServiceGetChannelNotificationSettingArgs {
  return &ChannelServiceGetChannelNotificationSettingArgs{}
}


func (p *ChannelServiceGetChannelNotificationSettingArgs) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelServiceGetChannelNotificationSettingArgs) GetLocale() string {
  return p.Locale
}
func (p *ChannelServiceGetChannelNotificationSettingArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.Locale = v
}
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelNotificationSetting_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceGetChannelNotificationSettingArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("locale", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:locale: ", p), err) }
  if err := oprot.WriteString(string(p.Locale)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.locale (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:locale: ", p), err) }
  return err
}

func (p *ChannelServiceGetChannelNotificationSettingArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelNotificationSettingArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetChannelNotificationSettingResult struct {
  Success *ChannelNotificationSetting `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetChannelNotificationSettingResult() *ChannelServiceGetChannelNotificationSettingResult {
  return &ChannelServiceGetChannelNotificationSettingResult{}
}

var ChannelServiceGetChannelNotificationSettingResult_Success_DEFAULT *ChannelNotificationSetting
func (p *ChannelServiceGetChannelNotificationSettingResult) GetSuccess() *ChannelNotificationSetting {
  if !p.IsSetSuccess() {
    return ChannelServiceGetChannelNotificationSettingResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetChannelNotificationSettingResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetChannelNotificationSettingResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetChannelNotificationSettingResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetChannelNotificationSettingResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetChannelNotificationSettingResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetChannelNotificationSettingResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelNotificationSetting{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelNotificationSetting_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelNotificationSettingResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelNotificationSettingResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelNotificationSettingResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelNotificationSettingResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
type ChannelServiceIssueChannelTokenArgs struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
}

func NewChannelServiceIssueChannelTokenArgs() *ChannelServiceIssueChannelTokenArgs {
  return &ChannelServiceIssueChannelTokenArgs{}
}


func (p *ChannelServiceIssueChannelTokenArgs) GetChannelId() string {
  return p.ChannelId
}
func (p *ChannelServiceIssueChannelTokenArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueChannelTokenArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceIssueChannelTokenArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueChannelToken_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueChannelTokenArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueChannelTokenArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueChannelTokenArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceIssueChannelTokenResult struct {
  Success *ChannelToken `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceIssueChannelTokenResult() *ChannelServiceIssueChannelTokenResult {
  return &ChannelServiceIssueChannelTokenResult{}
}

var ChannelServiceIssueChannelTokenResult_Success_DEFAULT *ChannelToken
func (p *ChannelServiceIssueChannelTokenResult) GetSuccess() *ChannelToken {
  if !p.IsSetSuccess() {
    return ChannelServiceIssueChannelTokenResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceIssueChannelTokenResult_E_DEFAULT *ChannelException
func (p *ChannelServiceIssueChannelTokenResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceIssueChannelTokenResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceIssueChannelTokenResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceIssueChannelTokenResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceIssueChannelTokenResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueChannelTokenResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelToken{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceIssueChannelTokenResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceIssueChannelTokenResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueChannelToken_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueChannelTokenResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueChannelTokenResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueChannelTokenResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueChannelTokenResult(%+v)", *p)
}

// Attributes:
//  - LastSynced
//  - Locale
type ChannelServiceGetChannelsArgs struct {
  // unused field # 1
  LastSynced int64 `thrift:"lastSynced,2" db:"lastSynced" json:"lastSynced"`
  Locale string `thrift:"locale,3" db:"locale" json:"locale"`
}

func NewChannelServiceGetChannelsArgs() *ChannelServiceGetChannelsArgs {
  return &ChannelServiceGetChannelsArgs{}
}


func (p *ChannelServiceGetChannelsArgs) GetLastSynced() int64 {
  return p.LastSynced
}

func (p *ChannelServiceGetChannelsArgs) GetLocale() string {
  return p.Locale
}
func (p *ChannelServiceGetChannelsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelsArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.LastSynced = v
}
  return nil
}

func (p *ChannelServiceGetChannelsArgs)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Locale = v
}
  return nil
}

func (p *ChannelServiceGetChannelsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannels_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelsArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("lastSynced", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:lastSynced: ", p), err) }
  if err := oprot.WriteI64(int64(p.LastSynced)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.lastSynced (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:lastSynced: ", p), err) }
  return err
}

func (p *ChannelServiceGetChannelsArgs) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("locale", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:locale: ", p), err) }
  if err := oprot.WriteString(string(p.Locale)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.locale (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:locale: ", p), err) }
  return err
}

func (p *ChannelServiceGetChannelsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetChannelsResult struct {
  Success *ChannelInfos `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetChannelsResult() *ChannelServiceGetChannelsResult {
  return &ChannelServiceGetChannelsResult{}
}

var ChannelServiceGetChannelsResult_Success_DEFAULT *ChannelInfos
func (p *ChannelServiceGetChannelsResult) GetSuccess() *ChannelInfos {
  if !p.IsSetSuccess() {
    return ChannelServiceGetChannelsResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetChannelsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetChannelsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetChannelsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetChannelsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetChannelsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetChannelsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelsResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelInfos{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannels_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelsResult(%+v)", *p)
}

// Attributes:
//  - LocalRev
type ChannelServiceFetchNotificationItemsArgs struct {
  // unused field # 1
  LocalRev int64 `thrift:"localRev,2" db:"localRev" json:"localRev"`
}

func NewChannelServiceFetchNotificationItemsArgs() *ChannelServiceFetchNotificationItemsArgs {
  return &ChannelServiceFetchNotificationItemsArgs{}
}


func (p *ChannelServiceFetchNotificationItemsArgs) GetLocalRev() int64 {
  return p.LocalRev
}
func (p *ChannelServiceFetchNotificationItemsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceFetchNotificationItemsArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.LocalRev = v
}
  return nil
}

func (p *ChannelServiceFetchNotificationItemsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("fetchNotificationItems_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceFetchNotificationItemsArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("localRev", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:localRev: ", p), err) }
  if err := oprot.WriteI64(int64(p.LocalRev)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.localRev (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:localRev: ", p), err) }
  return err
}

func (p *ChannelServiceFetchNotificationItemsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceFetchNotificationItemsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceFetchNotificationItemsResult struct {
  Success *NotificationFetchResult_ `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceFetchNotificationItemsResult() *ChannelServiceFetchNotificationItemsResult {
  return &ChannelServiceFetchNotificationItemsResult{}
}

var ChannelServiceFetchNotificationItemsResult_Success_DEFAULT *NotificationFetchResult_
func (p *ChannelServiceFetchNotificationItemsResult) GetSuccess() *NotificationFetchResult_ {
  if !p.IsSetSuccess() {
    return ChannelServiceFetchNotificationItemsResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceFetchNotificationItemsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceFetchNotificationItemsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceFetchNotificationItemsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceFetchNotificationItemsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceFetchNotificationItemsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceFetchNotificationItemsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceFetchNotificationItemsResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &NotificationFetchResult_{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceFetchNotificationItemsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceFetchNotificationItemsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("fetchNotificationItems_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceFetchNotificationItemsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceFetchNotificationItemsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceFetchNotificationItemsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceFetchNotificationItemsResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - Locale
type ChannelServiceGetChannelInfoArgs struct {
  // unused field # 1
  ChannelId string `thrift:"channelId,2" db:"channelId" json:"channelId"`
  Locale string `thrift:"locale,3" db:"locale" json:"locale"`
}

func NewChannelServiceGetChannelInfoArgs() *ChannelServiceGetChannelInfoArgs {
  return &ChannelServiceGetChannelInfoArgs{}
}


func (p *ChannelServiceGetChannelInfoArgs) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelServiceGetChannelInfoArgs) GetLocale() string {
  return p.Locale
}
func (p *ChannelServiceGetChannelInfoArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelInfoArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceGetChannelInfoArgs)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Locale = v
}
  return nil
}

func (p *ChannelServiceGetChannelInfoArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelInfo_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelInfoArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceGetChannelInfoArgs) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("locale", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:locale: ", p), err) }
  if err := oprot.WriteString(string(p.Locale)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.locale (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:locale: ", p), err) }
  return err
}

func (p *ChannelServiceGetChannelInfoArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelInfoArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetChannelInfoResult struct {
  Success *ChannelInfo `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetChannelInfoResult() *ChannelServiceGetChannelInfoResult {
  return &ChannelServiceGetChannelInfoResult{}
}

var ChannelServiceGetChannelInfoResult_Success_DEFAULT *ChannelInfo
func (p *ChannelServiceGetChannelInfoResult) GetSuccess() *ChannelInfo {
  if !p.IsSetSuccess() {
    return ChannelServiceGetChannelInfoResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetChannelInfoResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetChannelInfoResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetChannelInfoResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetChannelInfoResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetChannelInfoResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetChannelInfoResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelInfoResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelInfo{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelInfoResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetChannelInfoResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getChannelInfo_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetChannelInfoResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelInfoResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetChannelInfoResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetChannelInfoResult(%+v)", *p)
}

// Attributes:
//  - LocalRev
type ChannelServiceGetNotificationBadgeCountArgs struct {
  // unused field # 1
  LocalRev int64 `thrift:"localRev,2" db:"localRev" json:"localRev"`
}

func NewChannelServiceGetNotificationBadgeCountArgs() *ChannelServiceGetNotificationBadgeCountArgs {
  return &ChannelServiceGetNotificationBadgeCountArgs{}
}


func (p *ChannelServiceGetNotificationBadgeCountArgs) GetLocalRev() int64 {
  return p.LocalRev
}
func (p *ChannelServiceGetNotificationBadgeCountArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetNotificationBadgeCountArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.LocalRev = v
}
  return nil
}

func (p *ChannelServiceGetNotificationBadgeCountArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getNotificationBadgeCount_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetNotificationBadgeCountArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("localRev", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:localRev: ", p), err) }
  if err := oprot.WriteI64(int64(p.LocalRev)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.localRev (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:localRev: ", p), err) }
  return err
}

func (p *ChannelServiceGetNotificationBadgeCountArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetNotificationBadgeCountArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetNotificationBadgeCountResult struct {
  Success *int32 `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetNotificationBadgeCountResult() *ChannelServiceGetNotificationBadgeCountResult {
  return &ChannelServiceGetNotificationBadgeCountResult{}
}

var ChannelServiceGetNotificationBadgeCountResult_Success_DEFAULT int32
func (p *ChannelServiceGetNotificationBadgeCountResult) GetSuccess() int32 {
  if !p.IsSetSuccess() {
    return ChannelServiceGetNotificationBadgeCountResult_Success_DEFAULT
  }
return *p.Success
}
var ChannelServiceGetNotificationBadgeCountResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetNotificationBadgeCountResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetNotificationBadgeCountResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetNotificationBadgeCountResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetNotificationBadgeCountResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetNotificationBadgeCountResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.I32 {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetNotificationBadgeCountResult)  ReadField0(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI32(); err != nil {
  return thrift.PrependError("error reading field 0: ", err)
} else {
  p.Success = &v
}
  return nil
}

func (p *ChannelServiceGetNotificationBadgeCountResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetNotificationBadgeCountResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getNotificationBadgeCount_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetNotificationBadgeCountResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.I32, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteI32(int32(*p.Success)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T.success (0) field write error: ", p), err) }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetNotificationBadgeCountResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetNotificationBadgeCountResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetNotificationBadgeCountResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - OtpId
type ChannelServiceIssueRequestTokenArgs struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
  OtpId string `thrift:"otpId,2" db:"otpId" json:"otpId"`
}

func NewChannelServiceIssueRequestTokenArgs() *ChannelServiceIssueRequestTokenArgs {
  return &ChannelServiceIssueRequestTokenArgs{}
}


func (p *ChannelServiceIssueRequestTokenArgs) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelServiceIssueRequestTokenArgs) GetOtpId() string {
  return p.OtpId
}
func (p *ChannelServiceIssueRequestTokenArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.OtpId = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueRequestToken_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
    if err := p.writeField2(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueRequestTokenArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("otpId", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:otpId: ", p), err) }
  if err := oprot.WriteString(string(p.OtpId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.otpId (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:otpId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueRequestTokenArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceIssueRequestTokenResult struct {
  Success *string `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceIssueRequestTokenResult() *ChannelServiceIssueRequestTokenResult {
  return &ChannelServiceIssueRequestTokenResult{}
}

var ChannelServiceIssueRequestTokenResult_Success_DEFAULT string
func (p *ChannelServiceIssueRequestTokenResult) GetSuccess() string {
  if !p.IsSetSuccess() {
    return ChannelServiceIssueRequestTokenResult_Success_DEFAULT
  }
return *p.Success
}
var ChannelServiceIssueRequestTokenResult_E_DEFAULT *ChannelException
func (p *ChannelServiceIssueRequestTokenResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceIssueRequestTokenResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceIssueRequestTokenResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceIssueRequestTokenResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceIssueRequestTokenResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenResult)  ReadField0(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 0: ", err)
} else {
  p.Success = &v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueRequestToken_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueRequestTokenResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRING, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteString(string(*p.Success)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T.success (0) field write error: ", p), err) }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueRequestTokenResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueRequestTokenResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueRequestTokenResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
type ChannelServiceRevokeChannelArgs struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
}

func NewChannelServiceRevokeChannelArgs() *ChannelServiceRevokeChannelArgs {
  return &ChannelServiceRevokeChannelArgs{}
}


func (p *ChannelServiceRevokeChannelArgs) GetChannelId() string {
  return p.ChannelId
}
func (p *ChannelServiceRevokeChannelArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceRevokeChannelArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceRevokeChannelArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("revokeChannel_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceRevokeChannelArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceRevokeChannelArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceRevokeChannelArgs(%+v)", *p)
}

// Attributes:
//  - E
type ChannelServiceRevokeChannelResult struct {
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceRevokeChannelResult() *ChannelServiceRevokeChannelResult {
  return &ChannelServiceRevokeChannelResult{}
}

var ChannelServiceRevokeChannelResult_E_DEFAULT *ChannelException
func (p *ChannelServiceRevokeChannelResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceRevokeChannelResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceRevokeChannelResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceRevokeChannelResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceRevokeChannelResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceRevokeChannelResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("revokeChannel_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceRevokeChannelResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceRevokeChannelResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceRevokeChannelResult(%+v)", *p)
}

// Attributes:
//  - LastSynced
//  - Locale
type ChannelServiceGetApprovedChannelsArgs struct {
  // unused field # 1
  LastSynced int64 `thrift:"lastSynced,2" db:"lastSynced" json:"lastSynced"`
  Locale string `thrift:"locale,3" db:"locale" json:"locale"`
}

func NewChannelServiceGetApprovedChannelsArgs() *ChannelServiceGetApprovedChannelsArgs {
  return &ChannelServiceGetApprovedChannelsArgs{}
}


func (p *ChannelServiceGetApprovedChannelsArgs) GetLastSynced() int64 {
  return p.LastSynced
}

func (p *ChannelServiceGetApprovedChannelsArgs) GetLocale() string {
  return p.Locale
}
func (p *ChannelServiceGetApprovedChannelsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetApprovedChannelsArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.LastSynced = v
}
  return nil
}

func (p *ChannelServiceGetApprovedChannelsArgs)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Locale = v
}
  return nil
}

func (p *ChannelServiceGetApprovedChannelsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getApprovedChannels_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetApprovedChannelsArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("lastSynced", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:lastSynced: ", p), err) }
  if err := oprot.WriteI64(int64(p.LastSynced)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.lastSynced (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:lastSynced: ", p), err) }
  return err
}

func (p *ChannelServiceGetApprovedChannelsArgs) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("locale", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:locale: ", p), err) }
  if err := oprot.WriteString(string(p.Locale)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.locale (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:locale: ", p), err) }
  return err
}

func (p *ChannelServiceGetApprovedChannelsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetApprovedChannelsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetApprovedChannelsResult struct {
  Success *ApprovedChannelInfos `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetApprovedChannelsResult() *ChannelServiceGetApprovedChannelsResult {
  return &ChannelServiceGetApprovedChannelsResult{}
}

var ChannelServiceGetApprovedChannelsResult_Success_DEFAULT *ApprovedChannelInfos
func (p *ChannelServiceGetApprovedChannelsResult) GetSuccess() *ApprovedChannelInfos {
  if !p.IsSetSuccess() {
    return ChannelServiceGetApprovedChannelsResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetApprovedChannelsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetApprovedChannelsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetApprovedChannelsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetApprovedChannelsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetApprovedChannelsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetApprovedChannelsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetApprovedChannelsResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ApprovedChannelInfos{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetApprovedChannelsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetApprovedChannelsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getApprovedChannels_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetApprovedChannelsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetApprovedChannelsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetApprovedChannelsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetApprovedChannelsResult(%+v)", *p)
}

// Attributes:
//  - ChannelIds
type ChannelServiceGetFriendChannelMatricesArgs struct {
  ChannelIds []string `thrift:"channelIds,1" db:"channelIds" json:"channelIds"`
}

func NewChannelServiceGetFriendChannelMatricesArgs() *ChannelServiceGetFriendChannelMatricesArgs {
  return &ChannelServiceGetFriendChannelMatricesArgs{}
}


func (p *ChannelServiceGetFriendChannelMatricesArgs) GetChannelIds() []string {
  return p.ChannelIds
}
func (p *ChannelServiceGetFriendChannelMatricesArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetFriendChannelMatricesArgs)  ReadField1(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]string, 0, size)
  p.ChannelIds =  tSlice
  for i := 0; i < size; i ++ {
var _elem917 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _elem917 = v
}
    p.ChannelIds = append(p.ChannelIds, _elem917)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelServiceGetFriendChannelMatricesArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getFriendChannelMatrices_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetFriendChannelMatricesArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelIds", thrift.LIST, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelIds: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRING, len(p.ChannelIds)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelIds {
    if err := oprot.WriteString(string(v)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelIds: ", p), err) }
  return err
}

func (p *ChannelServiceGetFriendChannelMatricesArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetFriendChannelMatricesArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetFriendChannelMatricesResult struct {
  Success *FriendChannelMatricesResponse `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetFriendChannelMatricesResult() *ChannelServiceGetFriendChannelMatricesResult {
  return &ChannelServiceGetFriendChannelMatricesResult{}
}

var ChannelServiceGetFriendChannelMatricesResult_Success_DEFAULT *FriendChannelMatricesResponse
func (p *ChannelServiceGetFriendChannelMatricesResult) GetSuccess() *FriendChannelMatricesResponse {
  if !p.IsSetSuccess() {
    return ChannelServiceGetFriendChannelMatricesResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceGetFriendChannelMatricesResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetFriendChannelMatricesResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetFriendChannelMatricesResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetFriendChannelMatricesResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetFriendChannelMatricesResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetFriendChannelMatricesResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetFriendChannelMatricesResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &FriendChannelMatricesResponse{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceGetFriendChannelMatricesResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetFriendChannelMatricesResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getFriendChannelMatrices_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetFriendChannelMatricesResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetFriendChannelMatricesResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetFriendChannelMatricesResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetFriendChannelMatricesResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
//  - OtpId
//  - RedirectUrl
type ChannelServiceIssueRequestTokenForAutoLoginArgs struct {
  // unused field # 1
  ChannelId string `thrift:"channelId,2" db:"channelId" json:"channelId"`
  OtpId string `thrift:"otpId,3" db:"otpId" json:"otpId"`
  RedirectUrl string `thrift:"redirectUrl,4" db:"redirectUrl" json:"redirectUrl"`
}

func NewChannelServiceIssueRequestTokenForAutoLoginArgs() *ChannelServiceIssueRequestTokenForAutoLoginArgs {
  return &ChannelServiceIssueRequestTokenForAutoLoginArgs{}
}


func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) GetChannelId() string {
  return p.ChannelId
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) GetOtpId() string {
  return p.OtpId
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) GetRedirectUrl() string {
  return p.RedirectUrl
}
func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 4:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField4(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.OtpId = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs)  ReadField4(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 4: ", err)
} else {
  p.RedirectUrl = v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueRequestTokenForAutoLogin_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
    if err := p.writeField4(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("otpId", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:otpId: ", p), err) }
  if err := oprot.WriteString(string(p.OtpId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.otpId (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:otpId: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) writeField4(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("redirectUrl", thrift.STRING, 4); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 4:redirectUrl: ", p), err) }
  if err := oprot.WriteString(string(p.RedirectUrl)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.redirectUrl (4) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 4:redirectUrl: ", p), err) }
  return err
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueRequestTokenForAutoLoginArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceIssueRequestTokenForAutoLoginResult struct {
  Success *string `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceIssueRequestTokenForAutoLoginResult() *ChannelServiceIssueRequestTokenForAutoLoginResult {
  return &ChannelServiceIssueRequestTokenForAutoLoginResult{}
}

var ChannelServiceIssueRequestTokenForAutoLoginResult_Success_DEFAULT string
func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) GetSuccess() string {
  if !p.IsSetSuccess() {
    return ChannelServiceIssueRequestTokenForAutoLoginResult_Success_DEFAULT
  }
return *p.Success
}
var ChannelServiceIssueRequestTokenForAutoLoginResult_E_DEFAULT *ChannelException
func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceIssueRequestTokenForAutoLoginResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult)  ReadField0(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 0: ", err)
} else {
  p.Success = &v
}
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("issueRequestTokenForAutoLogin_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRING, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteString(string(*p.Success)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T.success (0) field write error: ", p), err) }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceIssueRequestTokenForAutoLoginResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceIssueRequestTokenForAutoLoginResult(%+v)", *p)
}

// Attributes:
//  - ChannelIds
type ChannelServiceGetUpdatedChannelIdsArgs struct {
  ChannelIds []*ChannelIdWithLastUpdated `thrift:"channelIds,1" db:"channelIds" json:"channelIds"`
}

func NewChannelServiceGetUpdatedChannelIdsArgs() *ChannelServiceGetUpdatedChannelIdsArgs {
  return &ChannelServiceGetUpdatedChannelIdsArgs{}
}


func (p *ChannelServiceGetUpdatedChannelIdsArgs) GetChannelIds() []*ChannelIdWithLastUpdated {
  return p.ChannelIds
}
func (p *ChannelServiceGetUpdatedChannelIdsArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetUpdatedChannelIdsArgs)  ReadField1(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]*ChannelIdWithLastUpdated, 0, size)
  p.ChannelIds =  tSlice
  for i := 0; i < size; i ++ {
    _elem918 := &ChannelIdWithLastUpdated{}
    if err := _elem918.Read(iprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", _elem918), err)
    }
    p.ChannelIds = append(p.ChannelIds, _elem918)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelServiceGetUpdatedChannelIdsArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getUpdatedChannelIds_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetUpdatedChannelIdsArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelIds", thrift.LIST, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelIds: ", p), err) }
  if err := oprot.WriteListBegin(thrift.STRUCT, len(p.ChannelIds)); err != nil {
    return thrift.PrependError("error writing list begin: ", err)
  }
  for _, v := range p.ChannelIds {
    if err := v.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", v), err)
    }
  }
  if err := oprot.WriteListEnd(); err != nil {
    return thrift.PrependError("error writing list end: ", err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelIds: ", p), err) }
  return err
}

func (p *ChannelServiceGetUpdatedChannelIdsArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetUpdatedChannelIdsArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceGetUpdatedChannelIdsResult struct {
  Success []string `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceGetUpdatedChannelIdsResult() *ChannelServiceGetUpdatedChannelIdsResult {
  return &ChannelServiceGetUpdatedChannelIdsResult{}
}

var ChannelServiceGetUpdatedChannelIdsResult_Success_DEFAULT []string

func (p *ChannelServiceGetUpdatedChannelIdsResult) GetSuccess() []string {
  return p.Success
}
var ChannelServiceGetUpdatedChannelIdsResult_E_DEFAULT *ChannelException
func (p *ChannelServiceGetUpdatedChannelIdsResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceGetUpdatedChannelIdsResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceGetUpdatedChannelIdsResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceGetUpdatedChannelIdsResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceGetUpdatedChannelIdsResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.LIST {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceGetUpdatedChannelIdsResult)  ReadField0(iprot thrift.TProtocol) error {
  _, size, err := iprot.ReadListBegin()
  if err != nil {
    return thrift.PrependError("error reading list begin: ", err)
  }
  tSlice := make([]string, 0, size)
  p.Success =  tSlice
  for i := 0; i < size; i ++ {
var _elem919 string
    if v, err := iprot.ReadString(); err != nil {
    return thrift.PrependError("error reading field 0: ", err)
} else {
    _elem919 = v
}
    p.Success = append(p.Success, _elem919)
  }
  if err := iprot.ReadListEnd(); err != nil {
    return thrift.PrependError("error reading list end: ", err)
  }
  return nil
}

func (p *ChannelServiceGetUpdatedChannelIdsResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceGetUpdatedChannelIdsResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("getUpdatedChannelIds_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceGetUpdatedChannelIdsResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.LIST, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteListBegin(thrift.STRING, len(p.Success)); err != nil {
      return thrift.PrependError("error writing list begin: ", err)
    }
    for _, v := range p.Success {
      if err := oprot.WriteString(string(v)); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T. (0) field write error: ", p), err) }
    }
    if err := oprot.WriteListEnd(); err != nil {
      return thrift.PrependError("error writing list end: ", err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetUpdatedChannelIdsResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceGetUpdatedChannelIdsResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceGetUpdatedChannelIdsResult(%+v)", *p)
}

// Attributes:
//  - Request
//  - Locale
type ChannelServiceReserveCoinUseArgs struct {
  // unused field # 1
  Request *CoinUseReservation `thrift:"request,2" db:"request" json:"request"`
  Locale string `thrift:"locale,3" db:"locale" json:"locale"`
}

func NewChannelServiceReserveCoinUseArgs() *ChannelServiceReserveCoinUseArgs {
  return &ChannelServiceReserveCoinUseArgs{}
}

var ChannelServiceReserveCoinUseArgs_Request_DEFAULT *CoinUseReservation
func (p *ChannelServiceReserveCoinUseArgs) GetRequest() *CoinUseReservation {
  if !p.IsSetRequest() {
    return ChannelServiceReserveCoinUseArgs_Request_DEFAULT
  }
return p.Request
}

func (p *ChannelServiceReserveCoinUseArgs) GetLocale() string {
  return p.Locale
}
func (p *ChannelServiceReserveCoinUseArgs) IsSetRequest() bool {
  return p.Request != nil
}

func (p *ChannelServiceReserveCoinUseArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceReserveCoinUseArgs)  ReadField2(iprot thrift.TProtocol) error {
  p.Request = &CoinUseReservation{}
  if err := p.Request.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Request), err)
  }
  return nil
}

func (p *ChannelServiceReserveCoinUseArgs)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Locale = v
}
  return nil
}

func (p *ChannelServiceReserveCoinUseArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("reserveCoinUse_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceReserveCoinUseArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("request", thrift.STRUCT, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:request: ", p), err) }
  if err := p.Request.Write(oprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Request), err)
  }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:request: ", p), err) }
  return err
}

func (p *ChannelServiceReserveCoinUseArgs) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("locale", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:locale: ", p), err) }
  if err := oprot.WriteString(string(p.Locale)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.locale (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:locale: ", p), err) }
  return err
}

func (p *ChannelServiceReserveCoinUseArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceReserveCoinUseArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceReserveCoinUseResult struct {
  Success *string `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceReserveCoinUseResult() *ChannelServiceReserveCoinUseResult {
  return &ChannelServiceReserveCoinUseResult{}
}

var ChannelServiceReserveCoinUseResult_Success_DEFAULT string
func (p *ChannelServiceReserveCoinUseResult) GetSuccess() string {
  if !p.IsSetSuccess() {
    return ChannelServiceReserveCoinUseResult_Success_DEFAULT
  }
return *p.Success
}
var ChannelServiceReserveCoinUseResult_E_DEFAULT *ChannelException
func (p *ChannelServiceReserveCoinUseResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceReserveCoinUseResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceReserveCoinUseResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceReserveCoinUseResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceReserveCoinUseResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceReserveCoinUseResult)  ReadField0(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 0: ", err)
} else {
  p.Success = &v
}
  return nil
}

func (p *ChannelServiceReserveCoinUseResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceReserveCoinUseResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("reserveCoinUse_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceReserveCoinUseResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRING, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := oprot.WriteString(string(*p.Success)); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T.success (0) field write error: ", p), err) }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceReserveCoinUseResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceReserveCoinUseResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceReserveCoinUseResult(%+v)", *p)
}

// Attributes:
//  - LastSynced
//  - Locale
type ChannelServiceSyncChannelDataArgs struct {
  // unused field # 1
  LastSynced int64 `thrift:"lastSynced,2" db:"lastSynced" json:"lastSynced"`
  Locale string `thrift:"locale,3" db:"locale" json:"locale"`
}

func NewChannelServiceSyncChannelDataArgs() *ChannelServiceSyncChannelDataArgs {
  return &ChannelServiceSyncChannelDataArgs{}
}


func (p *ChannelServiceSyncChannelDataArgs) GetLastSynced() int64 {
  return p.LastSynced
}

func (p *ChannelServiceSyncChannelDataArgs) GetLocale() string {
  return p.Locale
}
func (p *ChannelServiceSyncChannelDataArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 2:
      if fieldTypeId == thrift.I64 {
        if err := p.ReadField2(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 3:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField3(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceSyncChannelDataArgs)  ReadField2(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadI64(); err != nil {
  return thrift.PrependError("error reading field 2: ", err)
} else {
  p.LastSynced = v
}
  return nil
}

func (p *ChannelServiceSyncChannelDataArgs)  ReadField3(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 3: ", err)
} else {
  p.Locale = v
}
  return nil
}

func (p *ChannelServiceSyncChannelDataArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("syncChannelData_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField2(oprot); err != nil { return err }
    if err := p.writeField3(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceSyncChannelDataArgs) writeField2(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("lastSynced", thrift.I64, 2); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 2:lastSynced: ", p), err) }
  if err := oprot.WriteI64(int64(p.LastSynced)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.lastSynced (2) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 2:lastSynced: ", p), err) }
  return err
}

func (p *ChannelServiceSyncChannelDataArgs) writeField3(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("locale", thrift.STRING, 3); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 3:locale: ", p), err) }
  if err := oprot.WriteString(string(p.Locale)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.locale (3) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 3:locale: ", p), err) }
  return err
}

func (p *ChannelServiceSyncChannelDataArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceSyncChannelDataArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceSyncChannelDataResult struct {
  Success *ChannelSyncDatas `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceSyncChannelDataResult() *ChannelServiceSyncChannelDataResult {
  return &ChannelServiceSyncChannelDataResult{}
}

var ChannelServiceSyncChannelDataResult_Success_DEFAULT *ChannelSyncDatas
func (p *ChannelServiceSyncChannelDataResult) GetSuccess() *ChannelSyncDatas {
  if !p.IsSetSuccess() {
    return ChannelServiceSyncChannelDataResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceSyncChannelDataResult_E_DEFAULT *ChannelException
func (p *ChannelServiceSyncChannelDataResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceSyncChannelDataResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceSyncChannelDataResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceSyncChannelDataResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceSyncChannelDataResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceSyncChannelDataResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelSyncDatas{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceSyncChannelDataResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceSyncChannelDataResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("syncChannelData_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceSyncChannelDataResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceSyncChannelDataResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceSyncChannelDataResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceSyncChannelDataResult(%+v)", *p)
}

// Attributes:
//  - ChannelId
type ChannelServiceApproveChannelAndIssueChannelTokenArgs struct {
  ChannelId string `thrift:"channelId,1" db:"channelId" json:"channelId"`
}

func NewChannelServiceApproveChannelAndIssueChannelTokenArgs() *ChannelServiceApproveChannelAndIssueChannelTokenArgs {
  return &ChannelServiceApproveChannelAndIssueChannelTokenArgs{}
}


func (p *ChannelServiceApproveChannelAndIssueChannelTokenArgs) GetChannelId() string {
  return p.ChannelId
}
func (p *ChannelServiceApproveChannelAndIssueChannelTokenArgs) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 1:
      if fieldTypeId == thrift.STRING {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenArgs)  ReadField1(iprot thrift.TProtocol) error {
  if v, err := iprot.ReadString(); err != nil {
  return thrift.PrependError("error reading field 1: ", err)
} else {
  p.ChannelId = v
}
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenArgs) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("approveChannelAndIssueChannelToken_args"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenArgs) writeField1(oprot thrift.TProtocol) (err error) {
  if err := oprot.WriteFieldBegin("channelId", thrift.STRING, 1); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:channelId: ", p), err) }
  if err := oprot.WriteString(string(p.ChannelId)); err != nil {
  return thrift.PrependError(fmt.Sprintf("%T.channelId (1) field write error: ", p), err) }
  if err := oprot.WriteFieldEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write field end error 1:channelId: ", p), err) }
  return err
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenArgs) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceApproveChannelAndIssueChannelTokenArgs(%+v)", *p)
}

// Attributes:
//  - Success
//  - E
type ChannelServiceApproveChannelAndIssueChannelTokenResult struct {
  Success *ChannelToken `thrift:"success,0" db:"success" json:"success,omitempty"`
  E *ChannelException `thrift:"e,1" db:"e" json:"e,omitempty"`
}

func NewChannelServiceApproveChannelAndIssueChannelTokenResult() *ChannelServiceApproveChannelAndIssueChannelTokenResult {
  return &ChannelServiceApproveChannelAndIssueChannelTokenResult{}
}

var ChannelServiceApproveChannelAndIssueChannelTokenResult_Success_DEFAULT *ChannelToken
func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) GetSuccess() *ChannelToken {
  if !p.IsSetSuccess() {
    return ChannelServiceApproveChannelAndIssueChannelTokenResult_Success_DEFAULT
  }
return p.Success
}
var ChannelServiceApproveChannelAndIssueChannelTokenResult_E_DEFAULT *ChannelException
func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) GetE() *ChannelException {
  if !p.IsSetE() {
    return ChannelServiceApproveChannelAndIssueChannelTokenResult_E_DEFAULT
  }
return p.E
}
func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) IsSetSuccess() bool {
  return p.Success != nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) IsSetE() bool {
  return p.E != nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) Read(iprot thrift.TProtocol) error {
  if _, err := iprot.ReadStructBegin(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read error: ", p), err)
  }


  for {
    _, fieldTypeId, fieldId, err := iprot.ReadFieldBegin()
    if err != nil {
      return thrift.PrependError(fmt.Sprintf("%T field %d read error: ", p, fieldId), err)
    }
    if fieldTypeId == thrift.STOP { break; }
    switch fieldId {
    case 0:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField0(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    case 1:
      if fieldTypeId == thrift.STRUCT {
        if err := p.ReadField1(iprot); err != nil {
          return err
        }
      } else {
        if err := iprot.Skip(fieldTypeId); err != nil {
          return err
        }
      }
    default:
      if err := iprot.Skip(fieldTypeId); err != nil {
        return err
      }
    }
    if err := iprot.ReadFieldEnd(); err != nil {
      return err
    }
  }
  if err := iprot.ReadStructEnd(); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T read struct end error: ", p), err)
  }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult)  ReadField0(iprot thrift.TProtocol) error {
  p.Success = &ChannelToken{}
  if err := p.Success.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.Success), err)
  }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult)  ReadField1(iprot thrift.TProtocol) error {
  p.E = &ChannelException{}
  if err := p.E.Read(iprot); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T error reading struct: ", p.E), err)
  }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) Write(oprot thrift.TProtocol) error {
  if err := oprot.WriteStructBegin("approveChannelAndIssueChannelToken_result"); err != nil {
    return thrift.PrependError(fmt.Sprintf("%T write struct begin error: ", p), err) }
  if p != nil {
    if err := p.writeField0(oprot); err != nil { return err }
    if err := p.writeField1(oprot); err != nil { return err }
  }
  if err := oprot.WriteFieldStop(); err != nil {
    return thrift.PrependError("write field stop error: ", err) }
  if err := oprot.WriteStructEnd(); err != nil {
    return thrift.PrependError("write struct stop error: ", err) }
  return nil
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) writeField0(oprot thrift.TProtocol) (err error) {
  if p.IsSetSuccess() {
    if err := oprot.WriteFieldBegin("success", thrift.STRUCT, 0); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 0:success: ", p), err) }
    if err := p.Success.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.Success), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 0:success: ", p), err) }
  }
  return err
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) writeField1(oprot thrift.TProtocol) (err error) {
  if p.IsSetE() {
    if err := oprot.WriteFieldBegin("e", thrift.STRUCT, 1); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field begin error 1:e: ", p), err) }
    if err := p.E.Write(oprot); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T error writing struct: ", p.E), err)
    }
    if err := oprot.WriteFieldEnd(); err != nil {
      return thrift.PrependError(fmt.Sprintf("%T write field end error 1:e: ", p), err) }
  }
  return err
}

func (p *ChannelServiceApproveChannelAndIssueChannelTokenResult) String() string {
  if p == nil {
    return "<nil>"
  }
  return fmt.Sprintf("ChannelServiceApproveChannelAndIssueChannelTokenResult(%+v)", *p)
}