import os,sys,time,platform
def TeamTermux():
    if "Windows" in platform.platform():
            _ = os.system("cls")
    else:
        _ = os.system("clear")
TeamTermux()
os.system("go run zul.go zul")
