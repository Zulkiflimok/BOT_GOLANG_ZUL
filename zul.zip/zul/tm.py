'''
MADE BY ZULKIFLI MOKOAGOW
LINE ID : zul.1.02
'''
import os, sys
try:version = sys.argv[1]
except:version = "1.22.5"
file_name = f"go{version}.linux-amd64.tar.gz"
list_cmd = f"""
wget https://dl.google.com/go/{file_name}
rm -rf /usr/local/go && tar -C /usr/local -xzf {file_name}
rm -rf {file_name}""".split("\n")
for x in list_cmd:os.system(x)
auto_export = "export PATH=$PATH:/usr/local/go/bin"
profile_path = "/etc/profile"
text = open(profile_path, "r").read()
if auto_export not in text:
    open("/etc/profile","a").write("\n\n" + auto_export)
print("INSTALL SUCCESS. EXIT TERMINAL & LOGIN AGAIN")